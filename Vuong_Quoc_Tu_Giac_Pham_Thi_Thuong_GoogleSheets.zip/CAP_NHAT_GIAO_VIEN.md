# Cập nhật thông tin giáo viên – 29/10/2026

**Phạm Thị Thương - Trường THCS Hà Huy Tập**

- Cập nhật một nguồn cấu hình; hiển thị ở ngay dưới tên trò chơi, trang giáo viên và bằng khen cuối trò chơi. Không tạo thêm khối thông tin trùng.
- Dùng viền, màu, phông của giao diện gốc; ở khung rộng tối đa 480px, tên trường xuống dòng dưới tên giáo viên ở màn mở đầu/bằng khen. Trang giáo viên xuống dòng theo chiều rộng. Không dùng vị trí tuyệt đối hay chiều cao cố định cho dòng thông tin.
- Giữ nguyên câu hỏi, hình học, bộ sinh câu, tính điểm, luật chơi, âm thanh và các chức năng khác. Giữ nguyên từng byte các tệp ghi nhận tác giả/giấy phép.
- URL gửi Google Sheets vẫn trống. Không thêm thông tin hoặc kết quả học sinh.
- Kiểm tra UTF-8, chuỗi có dấu, điểm gọi hiển thị và cú pháp JavaScript; đối chiếu tệp ZIP trước/sau. Chưa chạy kiểm tra trực quan trên điện thoại thật; không coi việc kiểm tra CSS là xác nhận trên thiết bị thật.

Ghi nhận nguồn/giấy phép và báo cáo trước đây được giữ nguyên như tài liệu của bản nền. Các chỗ mô tả tên giáo viên/trường để trống trong tài liệu nền được thay thế bằng cấu hình cá nhân hóa nêu trên; riêng URL vẫn trống.
