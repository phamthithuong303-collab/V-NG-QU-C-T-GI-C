# Ghi nhận tác giả và giấy phép

## 1. Trò chơi gốc

- Tên: **Vương Quốc Hữu Tỉ**.
- Tên giáo viên/tác giả được ghi trong cấu hình bản gốc: **Vũ Như Huynh**.
- Chủ kho nguồn: `vunhuhuynh9a-pixel`.
- Kho nguồn: https://github.com/vunhuhuynh9a-pixel/HUU-TI
- Trang gốc: https://vunhuhuynh9a-pixel.github.io/HUU-TI/
- Mốc mã đã sử dụng và đối chiếu: `0795499a79d620fccbbaee1f099073952ec9a330`.
- README gốc ghi mã nguồn và câu hỏi được tự viết cho dự án; KaTeX dùng MIT; Baloo 2 và Nunito dùng SIL Open Font License.

**Tại mốc mã trên, không tìm thấy tệp LICENSE/COPYING riêng cấp phép cho toàn bộ trò chơi.** Không coi giấy phép MIT của KaTeX là giấy phép của cả dự án; bản chuyển thể này không tự cấp lại giấy phép cho mã gốc. Thông tin này phản ánh những tệp đã đọc, không suy đoán quyền cấp phép chưa được công bố. Việc công khai hoặc phân phối tiếp mã gốc cần phù hợp với sự cho phép của chủ sở hữu.

## 2. Bản chuyển nội dung

Tên: **Vương Quốc Tứ Giác – Toán 8 KNTT**. Được biên soạn/chỉnh sửa theo yêu cầu giáo viên với sự hỗ trợ của ChatGPT. Giữ mã nền, giao diện và hệ thống chơi của bản gốc; thay nội dung sang Chương III – Tứ giác và sửa các lỗi ghi trong `BAO_CAO_KIEM_TRA.html`. Không nhận là tác giả của mã nền gốc. Không kèm bản chụp SGK trong gói phân phối.

## 3. Thành phần bên thứ ba

| Thành phần | Ghi nhận | Văn bản giấy phép trong gói |
|---|---|---|
| KaTeX và tài nguyên đi kèm | Khan Academy và các cộng tác viên; thông báo bản quyền giữ nguyên | `vendor/katex/LICENSE` – MIT, sao chép nguyên từ nguồn gốc |
| Baloo 2 | The Baloo 2 Project Authors | `vendor/fonts/LICENSE-baloo2.txt` – SIL OFL 1.1 |
| Nunito | The Nunito Project Authors | `vendor/fonts/LICENSE-nunito.txt` – SIL OFL 1.1 |

Hai văn bản OFL được bổ sung từ kho Google Fonts chính thức ngày 29/10/2026; giữ nguyên nội dung, gồm thông báo bản quyền:
- https://github.com/google/fonts/blob/main/ofl/baloo2/OFL.txt
- https://github.com/google/fonts/blob/main/ofl/nunito/OFL.txt

Các tệp phông và KaTeX của bản gốc không bị thay đổi. Nhân vật dùng emoji của môi trường hiển thị; hình học bổ sung được dựng bằng SVG.

## 4. Dữ liệu và cấu hình bàn giao

Không sao chép URL nhận kết quả của tác giả. `du-lieu/cau-hinh.js` để trống tên giáo viên, trường và URL. Các tên có chữ “(mẫu)”, tên trong bài Toán và hồ sơ kiểm thử là dữ liệu minh họa, không phải danh sách học sinh thật. Không kèm tiến độ trình duyệt, kết quả thật, bảng tính học sinh, mã truy cập riêng hoặc mật khẩu Google.
