# Vương Quốc Tứ Giác

**Bản cá nhân hóa:** Giáo viên Phạm Thị Thương - Trường THCS Hà Huy Tập. Thông tin dùng chung tại `du-lieu/cau-hinh.js`; URL gửi kết quả vẫn để trống. Xem `CAP_NHAT_GIAO_VIEN.md` (bản trước) và `BAO_CAO_GOOGLE_SHEETS.html` (bản hiện tại). 

Bản chuyển nội dung từ **Vương Quốc Hữu Tỉ** sang **Chương III – Tứ giác, Toán 8, Kết nối tri thức với cuộc sống**. Chỉnh trực tiếp trên mã gốc, giữ hệ thống chơi và giao diện. Nguồn gốc: https://vunhuhuynh9a-pixel.github.io/HUU-TI/ ; bản đối chiếu commit `0795499a79d620fccbbaee1f099073952ec9a330`.

**Bắt đầu:** mở `HUONG_DAN.html` để xem hướng dẫn mở máy, đưa lên GitHub Pages, chỉnh câu hỏi và nối Google Sheets riêng. Xem `GHI_NHAN_TAC_GIA_VA_GIAY_PHEP.md` về nguồn và giấy phép.

**Đọc báo cáo bàn giao:** mở `BAO_CAO_KIEM_TRA.html`. Báo cáo phân biệt kiểm thử thực tế, kiểm thử logic, đọc mã và các phần chưa xác nhận trên thiết bị thật. Không coi các kiểm tra tự động là chứng minh mọi câu Toán đều đúng.

## 1. Mở trò chơi

Giải nén **toàn bộ** gói. Trên máy tính, mở `index.html` bằng trình duyệt có JavaScript. Giữ nguyên các thư mục đi kèm. Có thể dùng máy chủ tĩnh để chạy, chẳng hạn nếu đã có Python:

```
python -m http.server 8765
```

Chạy lệnh trong thư mục vừa giải nén, nơi có `index.html`, rồi mở `http://localhost:8765/`. Để học sinh dùng điện thoại, cần đưa toàn bộ nội dung thư mục này lên máy chủ web tĩnh của giáo viên và gửi địa chỉ truy cập; gói bàn giao chưa được đăng công khai.

Tiến độ lưu trên trình duyệt/thiết bị đang chơi. Không đồng bộ tiến độ giữa các máy. Bản này dùng vùng lưu riêng `tugq-`, không đọc đè tiến độ Số hữu tỉ. Nếu trình duyệt chặn lưu khi mở file trực tiếp, dùng máy chủ tĩnh. Tài nguyên KaTeX và phông chữ có sẵn trong `vendor/`.

## 2. Nội dung và luật chơi

| Vùng | Nội dung | Câu trong ngân hàng | Thử thách |
|---|---|---:|---:|
| 1 | Tứ giác | 27 | 6 |
| 2 | Hình thang cân | 26 | 6 |
| 3 | Hình bình hành | 26 | 6 |
| 4 | Hình chữ nhật | 26 | 6 |
| 5 | Hình thoi và hình vuông | 22 | 6 |

Tổng **127 câu**, đủ tám dạng: trắc nghiệm, đúng/sai, điền đáp số, sắp xếp số đo, chọn đối tượng trên hình, ghép đôi, bắt lỗi sai, sắp xếp bước chứng minh. Thêm **14 mẫu sinh câu** theo ba mức độ. Boss cuối vùng 5 ôn tập cả năm vùng, giữ hai giai đoạn.

Mỗi vùng giữ thứ tự: thường – thường – Đấu trí 60 giây – thường – thường – boss. Bốn lượt thường vùng 1–4 có 4, 4, 4, 5 câu; vùng 5 có 5, 5, 5, 5 câu. Giữ bốn lớp nhân vật, kỹ năng, ba mức khó, vật phẩm, giá cửa hàng, tim, XP, vàng, combo, 17 huy hiệu, hồi sinh và Hang Ôn Tập. Điều kiện qua lượt, số sao và thưởng theo mã gốc.

## 3. Tệp và cách chỉnh câu hỏi

| Tệp | Vai trò |
|---|---|
| `index.html` | Trang chơi |
| `giao-vien.html` | Nhập mã, thống kê, xuất CSV |
| `du-lieu/cau-hoi.js` | 127 câu; các trường đề, đáp án, gợi ý, lời giải, lỗi sai |
| `du-lieu/sinh-cau-hoi.js` | 14 mẫu ngẫu nhiên, tham số và điều kiện |
| `du-lieu/cot-truyen.js` | Vùng, thử thách, lời thoại, nhân vật, huy hiệu |
| `du-lieu/cau-hinh.js` | Tên giáo viên, trường, URL gửi kết quả |
| `js/hinh-hoc.js` | Hình SVG và chấm các thứ tự hợp lệ |
| `js/thu-thach.js` | Hiển thị/chấm tám dạng |
| `js/game.js` | Điều phối trò chơi, thưởng, mở khóa, lưu |
| `kiem-tra.html`, `js/kiem-tra.js` | Công cụ kiểm tra dữ liệu |
| `tests/` | Kiểm thử Node không cần cài thêm thư viện |
| `bao-cao/` | Kết quả kiểm tra và đối chiếu tệp |

Lưu mã bằng UTF-8. Không đổi mã câu đã sử dụng nếu vẫn là cùng câu. Trắc nghiệm dùng `phuongAn` và `dapAn` A–D theo thứ tự dữ liệu; khi chơi phương án được đảo nên lời giải không được viện dẫn chữ cái của phương án. Câu hình học dùng `hinh` F1–F5 và `doiTuong`; hình phải đúng với giả thiết, không dùng hình để thay thế dữ kiện. Câu chứng minh lưu mọi thứ tự hợp lệ trong `thuTuDung`. Câu sắp xếp số đo tách nhãn hiển thị `nhan` khỏi giá trị dùng để chấm `so`; các giá trị bằng nhau được đổi chỗ.

## 4. Kiểm tra sau khi sửa

Mở `kiem-tra.html`. Với Node đã cài, chạy:

```
node tests/kiem-tra.cjs
node tests/giao-vien.cjs
```

Bài kiểm tra thứ hai dùng DOM/dịch vụ Google giả lập, không gửi kết quả đi đâu. Để kiểm tra trải nghiệm cần chơi lại trên trình duyệt thật. Các câu khái niệm và chứng minh phải rà soát bằng chuyên môn Toán; công cụ đánh dấu 107 câu cần rà soát ngữ nghĩa thay vì tự khẳng định lời giải đúng.

## 5. Google Sheets riêng – phiên bản xác nhận máy chủ

Mở `HUONG_DAN_GOOGLE_SHEETS.html` và đọc `BAO_CAO_GOOGLE_SHEETS.html` trước khi triển khai. Mã hoàn chỉnh nằm trong `cong-cu/google-apps-script.gs`. Chạy `caiDat` trong Apps Script gắn với bảng tính của `phamthithuong303@gmail.com`, triển khai Web app bằng tài khoản chủ sở hữu với quyền Anyone nếu được phép, rồi dán URL `/exec` vào `du-lieu/cau-hinh.js`.

Trang học sinh không cần Gmail và không có quyền đọc danh sách lớp. POST không được coi là đã lưu; chỉ biên nhận máy chủ mới xác nhận thành công. Trang giáo viên giữ nhập mã và CSV; dữ liệu trực tuyến xem trong Google Sheets riêng với quyền Google.

Các kiểm thử mới:

```
node tests/google-sheets.cjs
node tests/tich-hop-luot-choi.cjs
```

## 6. Trang giáo viên và mã kết quả

Học sinh vào **Hồ sơ → Chép mã**, gửi mã cho giáo viên. Giáo viên mở `giao-vien.html`, dán các mã và bấm **Xem bảng xếp hạng**. Dùng bộ lọc lớp, xem các chủ đề cần hỗ trợ, chọn **Tải bảng (CSV)** hoặc chép bảng để dán vào bảng tính.

Mã mới bắt đầu `TG1-`; không dùng chung mã `HT1-` vì ý nghĩa thống kê kiến thức đã thay đổi. Mã có kiểm tra lỗi nhập, không phải chứng nhận chống gian lận. Dữ liệu mẫu ghi rõ “(mẫu)”.

## 7. Nguồn và tài nguyên

Bản gốc: kho HUU-TI của tài khoản `vunhuhuynh9a-pixel`; bản này giữ mã nền và ghi nhận nguồn, chỉ thay nội dung học tập và sửa lỗi nêu trong báo cáo. Không khẳng định quyền sở hữu toàn bộ mã gốc hoặc tự cấp lại giấy phép cho mã gốc.

KaTeX: xem `vendor/katex/LICENSE`. Phông Baloo 2 và Nunito cùng tài nguyên gốc được giữ nguyên. Hình học mới được dựng bằng SVG từ tọa độ xác định.
