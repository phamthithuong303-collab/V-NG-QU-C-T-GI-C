/* Vương Quốc Tứ Giác – Phạm Thị Thương – Trường THCS Hà Huy Tập.
 * Triển khai từ bảng tính riêng của phamthithuong303@gmail.com.
 * Chạy caiDat một lần trong trình biên tập; không cần mật khẩu Gmail trong mã.
 * POST ghi dữ liệu. GET chỉ xác nhận biên nhận; KHÔNG có API đọc danh sách lớp.
 */
const TG_TIMEZONE = 'Asia/Ho_Chi_Minh';
const TG_DETAIL = ['Thời gian (Việt Nam)','Mã học sinh','Họ tên','Lớp','Mã lượt chơi','Vùng/thử thách','Số câu đúng','Số câu sai','Tổng số câu','Tỉ lệ đúng (%)','Điểm trò chơi (XP lượt)','Thời gian làm bài (giây)','Số lần dùng gợi ý','Trạng thái hoàn thành','Số câu đã trả lời','Cơ sở tổng số câu','Số câu đã hiện','Số câu bỏ qua','XP tích lũy sau lượt','Mức độ','Loại lượt','Máy chủ nhận lúc (Việt Nam)'];
const TG_SUMMARY = ['Cập nhật lúc (Việt Nam)','Mã học sinh','Họ tên','Lớp','Mã hồ sơ thiết bị','XP tích lũy','Số câu đúng tích lũy','Số câu sai tích lũy','Số câu đã trả lời','Tỉ lệ đúng (%)','Thử thách đã vượt (/30)','Vùng đã vượt (/5)','Tổng sao (/90)','Trạng thái','Chủ đề cần luyện thêm','Tiến độ 30 thử thách','Thống kê chủ đề','Mã cập nhật mới nhất','Thời điểm dữ liệu (epoch ms)'];
const TG_RECEIPTS = ['Mã sự kiện','Băm khóa biên nhận','Băm dữ liệu','Trạng thái','Xác nhận lúc (epoch ms)'];
const TG_TOPICS = ["Khái niệm và yếu tố tứ giác","Tổng góc tứ giác","Định nghĩa và yếu tố hình thang cân","Tính chất hình thang cân","Nhận biết hình thang cân","Định nghĩa và tính chất hình bình hành","Nhận biết hình bình hành","Đường chéo hình bình hành","Định nghĩa và nhận biết hình chữ nhật","Đường chéo hình chữ nhật","Trung tuyến ứng với cạnh huyền","Tính chất và nhận biết hình thoi","Tính chất và nhận biết hình vuông","Lập luận và ôn tập toàn chương"];
const TG_STAGES = [["Cổng làng","Giếng Góc Đối","Đấu trí ở Chợ Phiên","Cầu Đường Chéo","Tháp Canh Tổng Góc","Hang Sói"],["Cổng thành","Lò rèn Góc Đáy","Đấu trí ở Quảng trường","Chợ Thành","Thư viện Dấu Hiệu","Tháp Đường Chéo"],["Bìa rừng","Suối Cạnh Đối","Đấu trí dưới Cây Cổ Thụ","Hang Hai Đường Chéo","Đồi Song Song","Tổ Rồng"],["Chân núi","Dốc Góc Vuông","Đấu trí trên Vách Đá","Cầu Trung Tuyến","Làng Trên Mây","Đỉnh núi"],["Cổng lâu đài","Hành lang Gương","Đấu trí ở Đại sảnh","Phòng Kho Báu","Tháp Phù thủy","Phòng Ngai Vàng"]];
function caiDat() {
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  if(!ss)throw Error('Mở Apps Script từ Google Sheets riêng của cô rồi chạy caiDat.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    PropertiesService.getScriptProperties().setProperty('TG_SPREADSHEET_ID',ss.getId());
    ss.setSpreadsheetTimeZone(TG_TIMEZONE);
    sheet_(ss,'ChiTietLuotChoi',TG_DETAIL);sheet_(ss,'TongHopHocSinh',TG_SUMMARY);
    sheet_(ss,'_BienNhan',TG_RECEIPTS).hideSheet();SpreadsheetApp.flush();
  }finally{lock.releaseLock();}
}
function db_(){const id=PropertiesService.getScriptProperties().getProperty('TG_SPREADSHEET_ID');if(!id)throw Error('not-configured');return SpreadsheetApp.openById(id);}
function sheet_(ss,name,headers){let sh=ss.getSheetByName(name);if(!sh){sh=ss.insertSheet(name);sh.getRange(1,1,1,headers.length).setValues([headers]);sh.setFrozenRows(1);}return sh;}
function locate_(sh,col,key){if(sh.getLastRow()<2)return 0;const xs=sh.getRange(2,col,sh.getLastRow()-1,1).getValues();for(let i=0;i<xs.length;i++)if(String(xs[i][0]).replace(/^'/,'')===key)return i+2;return 0;}
// Toàn bộ ô được đặt Plain text trước khi ghi, thêm dấu nháy bảo vệ tiền tố công thức.
function text_(v){const s=String(v==null?'':v);return /^[\s\u0000-\u001f]*[=+\-@]/.test(s)?"'"+s:s;}
function row_(sh,n,values){sh.getRange(n,1,1,values.length).setNumberFormat('@').setValues([values.map(text_)]);}
function stamp_(ms){return Utilities.formatDate(new Date(ms),TG_TIMEZONE,'dd/MM/yyyy HH:mm:ss');}
function hash_(s){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s,Utilities.Charset.UTF_8).map(x=>('0'+((x+256)%256).toString(16)).slice(-2)).join('');}
function obj_(x){return x&&typeof x==='object'&&!Array.isArray(x);}
function int_(x,max){return Number.isSafeInteger(x)&&x>=0&&x<=max;}
function string_(x,max){return typeof x==='string'&&x.trim().length>0&&x.length<=max&&!/[\u0000-\u001f\u007f]/.test(x);}
function ensure_(yes){if(!yes)throw Error('invalid-data');}
function envelope_(p){return obj_(p)&&/^[a-f0-9]{32}$/.test(p.eventId||'')&&/^[a-f0-9]{64}$/.test(p.receiptKey||'');}
function validate_(p){
 ensure_(envelope_(p)&&p.schema===2&&['attempt','summary'].includes(p.kind));
 const u=p.student,s=p.summary,d=p.detail;
 ensure_(obj_(u)&&/^[A-Z0-9_-]{1,32}$/.test(u.code||'')&&string_(u.name,80)&&string_(u.className,20));
 ensure_(int_(p.endedAt,Date.now()+86400000)&&p.endedAt>=1577836800000);
 ensure_(obj_(s)&&string_(s.profileId,64)&&int_(s.xp,100000000)&&int_(s.correct,1000000)&&int_(s.wrong,1000000)&&s.savedAt===p.endedAt&&typeof s.finished==='boolean');
 ensure_(Array.isArray(s.topics)&&s.topics.length===TG_TOPICS.length&&s.topics.every(x=>Array.isArray(x)&&x.length===2&&x.every(n=>int_(n,1000000))));
 ensure_(s.topics.reduce((a,x)=>a+x[0],0)===s.correct&&s.topics.reduce((a,x)=>a+x[1],0)===s.wrong);
 ensure_(Array.isArray(s.progress)&&s.progress.length===30&&s.progress.every(x=>Array.isArray(x)&&x.length===2&&x.every(n=>int_(n,3))&&((x[0]===0&&x[1]===0)||(x[0]>0&&x[1]>0))));
 ensure_(!s.finished||s.progress[29][0]>0);
 if(p.kind==='summary'){ensure_(d===null);return p;}
 ensure_(obj_(d)&&d.runId===p.eventId&&int_(d.region,5)&&int_(d.stage,6)&&['thu-thach','boss','dau-tri','on'].includes(d.mode)&&int_(d.difficulty,3)&&d.difficulty>=1);
 ensure_((d.mode==='on'&&d.region===0&&d.stage===0)||(d.region>=1&&d.stage>=1&&((d.mode==='dau-tri'&&d.stage===3)||(d.mode==='boss'&&d.stage===6)||(d.mode==='thu-thach'&&[1,2,4,5].includes(d.stage)))));
 for(const k of ['correct','wrong','total','shown','skipped','hints'])ensure_(int_(d[k],10000));
 ensure_(d.correct+d.wrong<=d.shown&&d.shown<=d.total&&d.skipped<=d.shown-d.correct-d.wrong&&d.hints<=d.shown);
 ensure_(['planned','shown'].includes(d.totalBasis)&&((['boss','dau-tri'].includes(d.mode)&&d.totalBasis==='shown'&&d.total===d.shown)||(['on','thu-thach'].includes(d.mode)&&d.totalBasis==='planned')));
 ensure_(int_(d.xpEarned,10000000)&&int_(d.xpTotal,100000000)&&d.xpTotal===s.xp&&d.xpEarned<=s.xp&&d.correct<=s.correct&&d.wrong<=s.wrong&&int_(d.elapsedMs,31536000000));
 ensure_(['hoan-thanh','chua-dat','rut-lui','on-xong'].includes(d.status));
 return p;
}
function json_(d){return ContentService.createTextOutput(JSON.stringify(d)).setMimeType(ContentService.MimeType.JSON);}
function doPost(e){
 let p;try{const raw=e&&e.postData&&e.postData.contents;ensure_(typeof raw==='string'&&raw.length<=30000);p=JSON.parse(raw);validate_(p);}catch(_){return json_({ok:false,error:'invalid-data'});}
 const lock=LockService.getScriptLock();if(!lock.tryLock(20000))return json_({ok:false,error:'busy-retry'});
 try{
  const ss=db_(),receipts=sheet_(ss,'_BienNhan',TG_RECEIPTS),digest=hash_(JSON.stringify(p)),keyHash=hash_(p.receiptKey);
  const receiptRow=locate_(receipts,1,p.eventId);
  if(receiptRow){const old=receipts.getRange(receiptRow,1,1,5).getValues()[0];if(old[1]!==keyHash||old[2]!==digest)return json_({ok:false,error:'event-conflict'});return json_({ok:true,eventId:p.eventId});}
  const now=Date.now(),u=p.student,s=p.summary,d=p.detail;
  if(d){const sh=sheet_(ss,'ChiTietLuotChoi',TG_DETAIL),n=locate_(sh,5,d.runId)||sh.getLastRow()+1;
   const answered=d.correct+d.wrong,rate=answered?Math.round(d.correct/answered*10000)/100:'';
   const area=d.mode==='on'?'Hang Ôn Tập':('V'+d.region+'-T'+d.stage+' · '+TG_STAGES[d.region-1][d.stage-1]);
   row_(sh,n,[stamp_(p.endedAt),u.code,u.name,u.className,d.runId,area,d.correct,d.wrong,d.total,rate,d.xpEarned,Math.round(d.elapsedMs)/1000,d.hints,d.status,answered,d.totalBasis==='planned'?'Số câu của lượt':'Số câu đã hiện',d.shown,d.skipped,d.xpTotal,d.difficulty,d.mode,stamp_(now)]);
  }
  const sh=sheet_(ss,'TongHopHocSinh',TG_SUMMARY),found=locate_(sh,2,u.code),n=found||sh.getLastRow()+1;
  const previous=found?Number(sh.getRange(found,19,1,1).getValues()[0][0]):0;
  if(p.endedAt>=previous){const answered=s.correct+s.wrong;
   const weak=s.topics.map((x,i)=>({n:x[0]+x[1],c:x[0],name:TG_TOPICS[i]})).filter(x=>x.n>=3&&x.c/x.n<.6).map(x=>x.name+' ('+x.c+'/'+x.n+')').join('; ');
   row_(sh,n,[stamp_(now),u.code,u.name,u.className,s.profileId,s.xp,s.correct,s.wrong,answered,answered?Math.round(s.correct/answered*10000)/100:'',s.progress.filter(x=>x[0]>0).length,[5,11,17,23,29].filter(i=>s.progress[i][0]>0).length,s.progress.reduce((a,x)=>a+x[0],0),s.finished?'Hoàn thành toàn bộ':'Đang luyện tập',weak||'Chưa có chủ đề đủ dữ liệu dưới 60%',JSON.stringify(s.progress),JSON.stringify(s.topics),p.eventId,p.endedAt]);
  }
  // Chỉ tạo biên nhận SAU khi cả hai bảng đã ghi xong. Retry sửa được ghi dở theo cùng runId.
  SpreadsheetApp.flush();row_(receipts,receipts.getLastRow()+1,[p.eventId,keyHash,digest,'saved',now]);SpreadsheetApp.flush();
  return json_({ok:true,eventId:p.eventId});
 }catch(_){return json_({ok:false,error:'server-retry'});}finally{lock.releaseLock();}
}
function doGet(e){
 const q=e&&e.parameter||{};
 if(q.action!=='receipt')return json_({service:'Vuong Quoc Tu Giac',schema:2,readClassData:false});
 if(!/^[a-f0-9]{32}$/.test(q.eventId||'')||!/^[a-f0-9]{64}$/.test(q.key||'')||!/^[a-f0-9]{32}$/.test(q.nonce||''))return json_({ok:false,error:'invalid-request'});
 const r={eventId:q.eventId,receiptKey:q.key,nonce:q.nonce,ok:false,state:'pending'};
 const lock=LockService.getScriptLock();
 if(lock.tryLock(10000)){try{const sh=db_().getSheetByName('_BienNhan');if(sh){const n=locate_(sh,1,q.eventId);if(n){const x=sh.getRange(n,1,1,5).getValues()[0];if(x[1]===hash_(q.key)&&x[3]==='saved'){r.ok=true;r.state='saved';r.savedAt=Number(x[4]);}}}}catch(_){r.state='pending';}finally{lock.releaseLock();}}
 // Callback cố định; không nhận tên hàm tùy ý. Không trả tên, lớp, điểm hay danh sách HS.
 return ContentService.createTextOutput('window.TGSheetsReceipt('+JSON.stringify(r)+');').setMimeType(ContentService.MimeType.JAVASCRIPT);
}
