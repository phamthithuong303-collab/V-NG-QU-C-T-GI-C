/* CẤU HÌNH DUY NHẤT: dán URL /exec từ Apps Script do cô tự triển khai.
 * Không dán địa chỉ Gmail hoặc URL trang tính vào urlKetQua. Không điền mật khẩu.
 * Để trống: kết quả chờ được giữ trên thiết bị, chưa gửi đi.
 */
window.CAU_HINH = {
  giaoVien: 'Phạm Thị Thương',
  truong: 'Trường THCS Hà Huy Tập',
  urlKetQua: ''
};
