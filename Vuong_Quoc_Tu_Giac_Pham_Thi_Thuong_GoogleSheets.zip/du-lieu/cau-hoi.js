// 127 câu tự biên soạn theo Chương III Tứ giác, Toán 8 KNTT.
window.CAU_HOI = [
  {
    "id": "TG-V1-01",
    "vung": 1,
    "chuDe": "Khái niệm tứ giác",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Mô tả nào đúng về một tứ giác ABCD?\n",
    "goiY": "Nhớ điều kiện về bốn cạnh và các đường thẳng chứa cạnh.",
    "loiGiai": [
      "Tứ giác được tạo bởi bốn đoạn AB, BC, CD, DA, trong đó không có hai đoạn nào nằm trên cùng một đường thẳng. Hình gồm ba đoạn AB, BC, CA là tam giác; bốn tia chung gốc và hai đoạn cắt nhau không mô tả tứ giác."
    ],
    "loiSai": "Chỉ đếm bốn nét mà bỏ qua cách nối và điều kiện thẳng hàng.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "Hình gồm ba đoạn AB, BC, CA.",
      "Hình gồm bốn đoạn AB, BC, CD, DA, trong đó không có hai đoạn nào nằm trên cùng một đường thẳng.",
      "Hình gồm bốn tia có chung gốc.",
      "Hình gồm hai đoạn thẳng cắt nhau."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V1-02",
    "vung": 1,
    "chuDe": "Tứ giác lồi",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Điền đặc điểm đúng của tứ giác lồi: với mỗi đường thẳng chứa một cạnh, hai đỉnh không thuộc cạnh ấy…\n",
    "goiY": "Xét vị trí hai đỉnh còn lại so với đường thẳng chứa cạnh.",
    "loiGiai": [
      "Điều kiện hai đỉnh còn lại nằm cùng phía đường thẳng chứa cạnh phải đúng với mọi cạnh của tứ giác lồi. Các phương án khác trái với định nghĩa."
    ],
    "loiSai": "Chỉ kiểm tra một cạnh rồi kết luận tứ giác lồi.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "luôn nằm khác phía đường thẳng.",
      "đều nằm trên đường thẳng.",
      "luôn nằm cùng một phía đường thẳng.",
      "trùng nhau."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V1-03",
    "vung": 1,
    "chuDe": "Đường chéo",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Trong tứ giác ABCD, các đỉnh được gọi theo thứ tự quanh hình. Cặp đoạn nào là hai đường chéo?\n",
    "goiY": "Đường chéo nối hai đỉnh đối nhau.",
    "loiGiai": [
      "A đối C, B đối D nên hai đường chéo là AC và BD. Các đoạn trong những phương án còn lại đều là cạnh."
    ],
    "loiSai": "Nhầm cạnh đối với đường chéo.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "AC và BD.",
      "AB và CD.",
      "AD và BC.",
      "AB và BC."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V1-04",
    "vung": 1,
    "chuDe": "Gọi tên tứ giác",
    "dang": "tu-giac",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Tứ giác có các đỉnh theo thứ tự A, B, C, D quanh biên. Cách gọi nào cũng chỉ đúng tứ giác đó theo thứ tự quanh biên?\n",
    "goiY": "Có thể đổi đỉnh bắt đầu nhưng phải đi liên tiếp quanh biên.",
    "loiGiai": [
      "Đi từ B theo biên gặp C, D rồi A, nên BCDA là tên đúng. Ba tên khác có bước đi qua đường chéo."
    ],
    "loiSai": "Cho rằng hoán vị tùy ý bốn chữ đều là tên đúng.",
    "dapAnDuyet": "D",
    "phuongAn": [
      "ACBD.",
      "ABDC.",
      "ADBC.",
      "BCDA."
    ],
    "dapAn": "D"
  },
  {
    "id": "TG-V1-05",
    "vung": 1,
    "chuDe": "Tổng góc",
    "dang": "goc-tu-giac",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Tổng các góc trong của một tứ giác lồi bằng bao nhiêu?\n",
    "goiY": "Kẻ một đường chéo để chia hình thành hai tam giác.",
    "loiGiai": [
      "Hai tam giác có tổng góc 2 × 180° = 360°. Các góc này ghép thành bốn góc trong của tứ giác."
    ],
    "loiSai": "Dùng tổng góc của tam giác cho tứ giác.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "180°.",
      "360°.",
      "270°.",
      "540°."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V1-06",
    "vung": 1,
    "chuDe": "Số góc tù",
    "dang": "goc-tu-giac",
    "muc": 3,
    "loai": "trac-nghiem",
    "de": "Một tứ giác lồi có thể có nhiều nhất bao nhiêu góc tù?\n",
    "goiY": "Bốn góc tù có tổng lớn hơn bao nhiêu độ?",
    "loiGiai": [
      "Bốn góc tù có tổng lớn hơn 360°, không thể xảy ra. Ba góc tù có thể xảy ra, chẳng hạn 100°, 100°, 100°, 60°. Vậy nhiều nhất là 3."
    ],
    "loiSai": "Nhầm “nhiều nhất ba” với “mọi tứ giác đều có ba góc tù”.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "1.",
      "2.",
      "3.",
      "4."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V1-07",
    "vung": 1,
    "chuDe": "Quan hệ góc",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Tứ giác ABCD có góc A = 90°, góc B = 90°, góc C = 65°. Góc D bằng bao nhiêu?\n",
    "goiY": "Lấy 360° trừ tổng ba góc đã biết.",
    "loiGiai": [
      "Góc D = 360° − 90° − 90° − 65° = 115°."
    ],
    "loiSai": "Cho rằng hai góc còn lại phải bằng nhau.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "115°.",
      "65°.",
      "25°.",
      "180°."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V1-08",
    "vung": 1,
    "chuDe": "Các yếu tố",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "dung-sai",
    "de": "Cho tứ giác ABCD với các đỉnh theo thứ tự quanh biên. Xác định đúng/sai:",
    "goiY": "Hai cạnh đối không có đỉnh chung.",
    "loiGiai": [
      "AB và CD không chung đỉnh; A và C không cùng thuộc một cạnh; AB và BC chung B nên là cạnh kề; BD nối hai đỉnh đối."
    ],
    "loiSai": "Nhầm cạnh kề với cạnh đối.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "AB và CD là hai cạnh đối.",
        "dung": true
      },
      {
        "nd": "A và C là hai đỉnh đối.",
        "dung": true
      },
      {
        "nd": "AB và BC là hai cạnh đối.",
        "dung": false
      },
      {
        "nd": "BD là một đường chéo.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V1-09",
    "vung": 1,
    "chuDe": "Tứ giác lồi",
    "dang": "tu-giac",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Xét các tứ giác lồi. Xác định đúng/sai:",
    "goiY": "Tách tính chất của tứ giác lồi khỏi tính chất của các hình đặc biệt.",
    "loiGiai": [
      "Góc trong của tứ giác lồi nhỏ hơn 180°; tổng là 360°; hai đường chéo cắt nhau bên trong. Không có giả thiết buộc hai đường chéo bằng nhau."
    ],
    "loiSai": "Gán tính chất hình chữ nhật cho mọi tứ giác.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "Mỗi góc trong nhỏ hơn 180°.",
        "dung": true
      },
      {
        "nd": "Tổng bốn góc bằng 360°.",
        "dung": true
      },
      {
        "nd": "Hai đường chéo luôn bằng nhau.",
        "dung": false
      },
      {
        "nd": "Hai đường chéo cắt nhau tại một điểm nằm trong mỗi đường chéo.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V1-10",
    "vung": 1,
    "chuDe": "Góc vuông và góc nhọn",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai đối với tứ giác lồi:",
    "goiY": "Dùng tổng 360°; với khẳng định d hãy thử 100°, 100°, 90°, 70°.",
    "loiGiai": [
      "a: góc còn lại bằng 360° − 270° = 90°. b: bốn góc nhọn có tổng nhỏ hơn 360°. c: 360° − 250° = 110°. d sai vì có thể còn một góc vuông."
    ],
    "loiSai": "Kết luận tất cả các góc còn lại phải cùng loại.",
    "dapAnDuyet": "a Đ; b S; c Đ; d S",
    "y": [
      {
        "nd": "Nếu có ba góc vuông thì góc còn lại vuông.",
        "dung": true
      },
      {
        "nd": "Có thể có bốn góc nhọn.",
        "dung": false
      },
      {
        "nd": "Nếu ba góc lần lượt là 70°, 80°, 100° thì góc còn lại là 110°.",
        "dung": true
      },
      {
        "nd": "Nếu có hai góc tù thì hai góc còn lại nhất thiết đều nhọn.",
        "dung": false
      }
    ]
  },
  {
    "id": "TG-V1-11",
    "vung": 1,
    "chuDe": "Kiểm tra dữ kiện góc",
    "dang": "goc-tu-giac",
    "muc": 3,
    "loai": "dung-sai",
    "de": "Các bộ số dưới đây được đề xuất làm bốn góc trong của một tứ giác lồi. Khẳng định “bộ số không mâu thuẫn với điều kiện góc của tứ giác lồi” đúng hay sai?",
    "goiY": "Kiểm tra cả tổng góc lẫn giới hạn mỗi góc.",
    "loiGiai": [
      "a và c có tổng 360°, mọi góc nằm giữa 0° và 180°. b có tổng 370°. d có tổng 360° nhưng có góc 190°, không phù hợp tứ giác lồi."
    ],
    "loiSai": "Chỉ kiểm tra tổng 360° mà bỏ qua tính lồi.",
    "dapAnDuyet": "a Đ; b S; c Đ; d S",
    "y": [
      {
        "nd": "50°, 80°, 100°, 130°.",
        "dung": true
      },
      {
        "nd": "90°, 90°, 90°, 100°.",
        "dung": false
      },
      {
        "nd": "40°, 70°, 90°, 160°.",
        "dung": true
      },
      {
        "nd": "20°, 30°, 120°, 190°.",
        "dung": false
      }
    ]
  },
  {
    "id": "TG-V1-12",
    "vung": 1,
    "chuDe": "Tính góc",
    "dang": "goc-tu-giac",
    "muc": 1,
    "loai": "dien",
    "de": "Tứ giác ABCD có góc A = 75°, góc B = 95°, góc C = 110°. Tính số đo góc D, đơn vị độ.",
    "goiY": "Tổng bốn góc là 360°.",
    "loiGiai": [
      "Góc D = 360° − (75° + 95° + 110°) = 80°."
    ],
    "loiSai": "Cộng thiếu một góc đã biết.",
    "dapAnDuyet": "80",
    "dapAn": "80",
    "donVi": "°"
  },
  {
    "id": "TG-V1-13",
    "vung": 1,
    "chuDe": "Tính góc",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "dien",
    "de": "Tứ giác ABCD có góc A = 80°, góc B = 100° và góc C bằng góc D. Tính số đo góc C, đơn vị độ.",
    "goiY": "Tìm tổng C và D trước.",
    "loiGiai": [
      "C + D = 360° − 180° = 180°. Do C = D nên C = 90°."
    ],
    "loiSai": "Lấy 180° làm số đo của từng góc.",
    "dapAnDuyet": "90",
    "dapAn": "90",
    "donVi": "°"
  },
  {
    "id": "TG-V1-14",
    "vung": 1,
    "chuDe": "Góc theo tỉ số",
    "dang": "goc-tu-giac",
    "muc": 3,
    "loai": "dien",
    "de": "Bốn góc A, B, C, D của một tứ giác lồi có số đo tỉ lệ 2 : 3 : 4 : 3. Tính số đo góc C, đơn vị độ.",
    "goiY": "Tổng số phần bằng nhau là 12.",
    "loiGiai": [
      "Mỗi phần bằng 360° : 12 = 30°. Góc C gồm 4 phần nên bằng 120°."
    ],
    "loiSai": "Chia 360° cho 4 thay vì cho tổng số phần.",
    "dapAnDuyet": "120",
    "dapAn": "120",
    "donVi": "°"
  },
  {
    "id": "TG-V1-15",
    "vung": 1,
    "chuDe": "Góc ngoài",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "dien",
    "de": "Trong tứ giác ABCD, góc A = 80°, góc B = 100°, góc C = 70°. Kéo dài AD qua D đến E. Tính góc CDE, đơn vị độ.",
    "goiY": "Góc ADC và CDE là hai góc kề bù.",
    "loiGiai": [
      "Góc ADC = 360° − 250° = 110°. Góc CDE = 180° − 110° = 70°."
    ],
    "loiSai": "Trả lời góc trong tại D thay vì góc được hỏi.",
    "dapAnDuyet": "70",
    "dapAn": "70",
    "donVi": "°"
  },
  {
    "id": "TG-V1-16",
    "vung": 1,
    "chuDe": "Hai góc hơn kém",
    "dang": "goc-tu-giac",
    "muc": 3,
    "loai": "dien",
    "de": "Tứ giác ABCD có góc A = 70°, góc B = 90°; góc C lớn hơn góc D 20°. Tính số đo góc D, đơn vị độ.",
    "goiY": "Tổng C và D là 200°.",
    "loiGiai": [
      "C + D = 200°; C = D + 20°. Suy ra 2D = 180°, D = 90° và C = 110°."
    ],
    "loiSai": "Trừ 20° rồi quên chia đôi.",
    "dapAnDuyet": "90",
    "dapAn": "90",
    "donVi": "°"
  },
  {
    "id": "TG-V1-17",
    "vung": 1,
    "chuDe": "So sánh số đo góc",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Tứ giác ABCD có A = 50°, B = 80°, C = 100°. Hãy sắp xếp bốn thẻ theo số đo tăng dần: góc D; góc B; góc A; góc C.",
    "goiY": "Tính góc D trước khi sắp xếp.",
    "loiGiai": [
      "D = 360° − 230° = 130°. Vậy 50° < 80° < 100° < 130°."
    ],
    "loiSai": "Sắp xếp theo thứ tự chữ cái mà không tính góc thiếu.",
    "dapAnDuyet": "A → B → C → D",
    "nhan": [
      "Góc D",
      "Góc B",
      "Góc A",
      "Góc C"
    ],
    "so": [
      "130",
      "80",
      "50",
      "100"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V1-18",
    "vung": 1,
    "chuDe": "So sánh số đo góc",
    "dang": "goc-tu-giac",
    "muc": 3,
    "loai": "sap-xep",
    "de": "Tứ giác ABCD có A = 40°, B = 70°; C lớn hơn D 30°. Xếp các thẻ góc B; góc D; góc A; góc C theo số đo giảm dần.",
    "goiY": "Tìm tổng và hiệu của C, D.",
    "loiGiai": [
      "C + D = 250°, C − D = 30° nên C = 140°, D = 110°. Thứ tự giảm dần là C, D, B, A."
    ],
    "loiSai": "Đảo chiều tăng và giảm; coi C + D là một góc.",
    "dapAnDuyet": "C → D → B → A",
    "nhan": [
      "Góc B",
      "Góc D",
      "Góc A",
      "Góc C"
    ],
    "so": [
      "70",
      "110",
      "40",
      "140"
    ],
    "chieu": "giam"
  },
  {
    "id": "TG-V1-19",
    "vung": 1,
    "chuDe": "Nhận diện đường chéo",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "chon-hinh",
    "de": "Quan sát hình F1: tứ giác ABCD có vẽ hai đường chéo. Chọn đoạn nối hai đỉnh đối A và C. Các đối tượng có thể chọn: AB, BC, CD, DA, AC, BD.",
    "goiY": "Tìm đúng hai đầu mút A và C.",
    "loiGiai": [
      "Đoạn nối A với C là AC. Đây là một đường chéo của tứ giác."
    ],
    "loiSai": "Chọn cạnh qua A nhưng không đi tới C.",
    "dapAnDuyet": "AC",
    "hinh": "F1",
    "doiTuong": [
      "AB",
      "BC",
      "CD",
      "DA",
      "AC",
      "BD"
    ],
    "dapAn": "AC"
  },
  {
    "id": "TG-V1-20",
    "vung": 1,
    "chuDe": "Nhận diện cạnh đối",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "chon-hinh",
    "de": "Quan sát hình F1. Chọn cạnh đối với cạnh AB. Các đối tượng có thể chọn: AB, BC, CD, DA, AC, BD.",
    "goiY": "Cạnh đối không chung đầu mút với AB.",
    "loiGiai": [
      "Trong bốn cạnh, chỉ CD không chứa A hoặc B, nên CD đối với AB."
    ],
    "loiSai": "Chọn AC vì nhầm đỉnh đối với cạnh đối.",
    "dapAnDuyet": "CD",
    "hinh": "F1",
    "doiTuong": [
      "AB",
      "BC",
      "CD",
      "DA",
      "AC",
      "BD"
    ],
    "dapAn": "CD"
  },
  {
    "id": "TG-V1-21",
    "vung": 1,
    "chuDe": "Thuật ngữ",
    "dang": "tu-giac",
    "muc": 1,
    "loai": "ghep",
    "de": "Ghép mỗi mục bên trái với mô tả bên phải; mỗi mô tả dùng một lần.",
    "goiY": "Phân biệt điểm và đoạn thẳng.",
    "loiGiai": [
      "A là điểm đỉnh; AB nối hai đỉnh kề; AC nối hai đỉnh đối."
    ],
    "loiSai": "Coi mọi đoạn nối hai đỉnh đều là cạnh.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "A",
        "phai": "Một đỉnh của ABCD"
      },
      {
        "trai": "AB",
        "phai": "Một cạnh của ABCD"
      },
      {
        "trai": "AC",
        "phai": "Một đường chéo của ABCD"
      }
    ]
  },
  {
    "id": "TG-V1-22",
    "vung": 1,
    "chuDe": "Góc còn thiếu",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "ghep",
    "de": "Mỗi bộ bên trái cho ba góc của một tứ giác. Ghép với góc thứ tư.",
    "goiY": "Mỗi lần lấy 360° trừ tổng ba góc.",
    "loiGiai": [
      "Các góc thiếu lần lượt là 360° − 240° = 120°; 360° − 270° = 90°; 360° − 285° = 75°."
    ],
    "loiSai": "Dùng 180° làm tổng góc.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "60°, 80°, 100°",
        "phai": "120°"
      },
      {
        "trai": "70°, 90°, 110°",
        "phai": "90°"
      },
      {
        "trai": "85°, 95°, 105°",
        "phai": "75°"
      }
    ]
  },
  {
    "id": "TG-V1-23",
    "vung": 1,
    "chuDe": "Các cặp đối nhau",
    "dang": "tu-giac",
    "muc": 2,
    "loai": "ghep",
    "de": "Trong tứ giác ABCD, ghép mỗi đối tượng với đối tượng đối diện cùng loại.",
    "goiY": "Đỉnh, cạnh và góc phải được ghép đúng loại.",
    "loiGiai": [
      "B đối D; AD đối BC; góc A đối góc C theo thứ tự đỉnh quanh tứ giác."
    ],
    "loiSai": "Ghép đỉnh với cạnh hoặc nhầm cạnh kề.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "Đỉnh B",
        "phai": "Đỉnh D"
      },
      {
        "trai": "Cạnh AD",
        "phai": "Cạnh BC"
      },
      {
        "trai": "Góc A",
        "phai": "Góc C"
      }
    ]
  },
  {
    "id": "TG-V1-24",
    "vung": 1,
    "chuDe": "Lỗi tổng góc",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "bat-loi",
    "de": "Cho tứ giác ABCD có A = 80°, B = 100°, C = 90°. Tìm bước sai đầu tiên.",
    "goiY": "Kiểm tra định lí dùng ở dòng đầu.",
    "loiGiai": [
      "Tổng góc tứ giác là 360°, không phải 180°. Đúng là D = 360° − 270° = 90°. Các bước sau chỉ tiếp tục từ tiền đề sai."
    ],
    "loiSai": "Chọn bước 3 chỉ vì kết quả âm, bỏ qua lỗi xuất phát.",
    "dapAnDuyet": "Bước 1",
    "vanBan": true,
    "buoc": [
      "A + B + C + D = 180°.",
      "D = 180° − (80° + 100° + 90°).",
      "D = −90°."
    ],
    "buocSai": 1,
    "dau": ""
  },
  {
    "id": "TG-V1-25",
    "vung": 1,
    "chuDe": "Lỗi tính góc",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "bat-loi",
    "de": "Cho tứ giác ABCD có A = 75°, B = 85°, C = 120°. Tìm bước sai đầu tiên.",
    "goiY": "Tính lại tổng ba số trong ngoặc.",
    "loiGiai": [
      "75 + 85 + 120 = 280, không phải 260. Vì vậy D = 80°. Bước 3 đúng về phép trừ nhưng dựa trên số sai ở bước 2."
    ],
    "loiSai": "Đổ lỗi cho định lí tổng góc thay vì phép cộng.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "D = 360° − (75° + 85° + 120°).",
      "D = 360° − 260°.",
      "D = 100°."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V1-26",
    "vung": 1,
    "chuDe": "Chứng minh tổng góc",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho tứ giác lồi ABCD. Sắp xếp các thẻ để chứng minh tổng bốn góc bằng 360°.",
    "goiY": "Phải tạo hai tam giác trước khi áp dụng tổng góc.",
    "loiGiai": [
      "Q tạo hình phụ; S áp dụng định lí; P cộng đẳng thức; R nhận diện tổng bốn góc tứ giác. Mỗi bước sau sử dụng kết quả trước."
    ],
    "loiSai": "Ghép góc hoặc cộng đẳng thức trước khi có hai đẳng thức cần dùng.",
    "dapAnDuyet": "Q → S → P → R; chỉ chấp nhận thứ tự này",
    "buoc": [
      "P: Cộng hai đẳng thức tổng góc của hai tam giác được tổng bằng 360°.",
      "Q: Kẻ đường chéo AC, chia tứ giác thành hai tam giác ABC và ACD.",
      "R: Ghép hai góc tại A và hai góc tại C để được A + B + C + D = 360°.",
      "S: Viết tổng góc của mỗi tam giác ABC và ACD bằng 180°."
    ],
    "thuTuDung": [
      [
        1,
        3,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V1-27",
    "vung": 1,
    "chuDe": "Chứng minh góc vuông",
    "dang": "goc-tu-giac",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Tứ giác ABCD có A = B = C = 90°. Sắp xếp các thẻ để chứng minh góc D vuông.",
    "goiY": "Hai nhận xét đầu độc lập; kết luận phải đứng cuối.",
    "loiGiai": [
      "Q và R cùng cung cấp dữ kiện để suy ra P; không có yêu cầu Q phải trước R. Bộ chấm phải chấp nhận cả hai thứ tự."
    ],
    "loiSai": "Bắt buộc một thứ tự giữa hai bước độc lập.",
    "dapAnDuyet": "Q → R → P hoặc R → Q → P",
    "buoc": [
      "P: Suy ra D = 360° − 270° = 90°, nên D là góc vuông.",
      "Q: A + B + C = 270° từ giả thiết.",
      "R: A + B + C + D = 360° theo tổng góc tứ giác."
    ],
    "thuTuDung": [
      [
        1,
        2,
        0
      ],
      [
        2,
        1,
        0
      ]
    ]
  },
  {
    "id": "TG-V2-01",
    "vung": 2,
    "chuDe": "Định nghĩa hình thang",
    "dang": "thang-can",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Điều kiện nào đủ để một tứ giác là hình thang?\n",
    "goiY": "Nhớ định nghĩa hình thang.",
    "loiGiai": [
      "Theo định nghĩa, tứ giác có hai cạnh đối song song là hình thang. Ba điều kiện còn lại không bảo đảm điều đó."
    ],
    "loiSai": "Nhầm tính chất của một hình đặc biệt với định nghĩa hình thang.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "Có hai cạnh đối song song.",
      "Có hai cạnh kề bằng nhau.",
      "Có một góc vuông.",
      "Có hai đường chéo cắt nhau."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V2-02",
    "vung": 2,
    "chuDe": "Định nghĩa hình thang cân",
    "dang": "thang-can",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Cho hình thang ABCD có AB ∥ CD. Điều kiện nào nhận biết hình thang cân theo định nghĩa?\n",
    "goiY": "Hai góc được so sánh phải kề cùng một đáy.",
    "loiGiai": [
      "DAB và ABC là hai góc kề đáy AB. Hai góc ấy bằng nhau thì hình thang cân. Hai góc kề một cạnh bên bù nhau là tính chất chung của hình thang, chưa đủ để kết luận hình thang cân."
    ],
    "loiSai": "Chọn tổng hai góc kề cạnh bên bằng 180° làm dấu hiệu cân.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "AB = CD.",
      "Góc DAB = góc ABC.",
      "AC vuông góc BD.",
      "Góc DAB + góc ADC = 180°."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V2-03",
    "vung": 2,
    "chuDe": "Tính chất cạnh bên",
    "dang": "can-tinh-chat",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Hình thang cân ABCD có AB ∥ CD. Cặp đoạn nào luôn bằng nhau?\n",
    "goiY": "Xác định hai cạnh bên theo hai đáy đã cho.",
    "loiGiai": [
      "Hai đáy là AB, CD nên hai cạnh bên là AD, BC. Trong hình thang cân, AD = BC."
    ],
    "loiSai": "Cho rằng hai đáy của hình thang cân bằng nhau.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "AB và CD.",
      "AB và BC.",
      "AD và BC.",
      "AC và AB."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V2-04",
    "vung": 2,
    "chuDe": "Dấu hiệu đường chéo",
    "dang": "can-nhan-biet",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Cho hình thang ABCD, AB ∥ CD. Biết AC = BD. Kết luận nào chắc chắn đúng?\n",
    "goiY": "Áp dụng dấu hiệu nhận biết hình thang cân.",
    "loiGiai": [
      "Một hình thang có hai đường chéo bằng nhau là hình thang cân. Không có dữ kiện buộc hai đáy bằng nhau hoặc góc vuông."
    ],
    "loiSai": "Suy ra hình có các góc vuông chỉ từ hai đường chéo bằng nhau.",
    "dapAnDuyet": "D",
    "phuongAn": [
      "AB = CD.",
      "Bốn cạnh bằng nhau.",
      "Mọi góc đều vuông.",
      "ABCD là hình thang cân."
    ],
    "dapAn": "D"
  },
  {
    "id": "TG-V2-05",
    "vung": 2,
    "chuDe": "Tính góc",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Hình thang cân ABCD có AB ∥ CD và góc ADC = 65°. Góc ABC bằng bao nhiêu?\n",
    "goiY": "Tính góc A rồi dùng hai góc kề đáy AB.",
    "loiGiai": [
      "A + D = 180° nên A = 115°. Hình thang cân có A = B, do đó B = 115°."
    ],
    "loiSai": "Cho mọi góc của hình thang cân bằng nhau.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "65°.",
      "115°.",
      "25°.",
      "130°."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V2-06",
    "vung": 2,
    "chuDe": "Giả thiết cần thiết",
    "dang": "can-nhan-biet",
    "muc": 3,
    "loai": "trac-nghiem",
    "de": "Cho tứ giác ABCD có AC = BD. Bổ sung điều kiện nào dưới đây để áp dụng trực tiếp dấu hiệu nhận biết hình thang cân trong SGK?\n",
    "goiY": "Dấu hiệu nói về một hình thang, không phải mọi tứ giác.",
    "loiGiai": [
      "AB ∥ CD xác nhận ABCD là hình thang; kết hợp AC = BD suy ra hình thang cân. Các phương án còn lại không cung cấp đủ điều kiện song song."
    ],
    "loiSai": "Bỏ qua giả thiết hình thang khi dùng dấu hiệu đường chéo.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "AB ∥ CD.",
      "AB và BC chung đỉnh B.",
      "AC và BD cắt nhau.",
      "Bốn đỉnh phân biệt."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V2-07",
    "vung": 2,
    "chuDe": "Các yếu tố hình thang",
    "dang": "thang-can",
    "muc": 1,
    "loai": "dung-sai",
    "de": "Cho hình thang ABCD có AB ∥ CD. Xác định đúng/sai:",
    "goiY": "Đường cao phải vuông góc đáy, nhưng cạnh bên không nhất thiết là đường cao.",
    "loiGiai": [
      "a, b đúng theo tên các yếu tố; c đúng do hai đường thẳng song song; d không có trong giả thiết."
    ],
    "loiSai": "Coi cạnh bên bất kỳ là đường cao.",
    "dapAnDuyet": "a Đ; b Đ; c Đ; d S",
    "y": [
      {
        "nd": "AB và CD có thể được chọn làm hai đáy.",
        "dung": true
      },
      {
        "nd": "AD và BC là hai cạnh bên theo hai đáy đã chọn.",
        "dung": true
      },
      {
        "nd": "Hai góc DAB và ADC bù nhau.",
        "dung": true
      },
      {
        "nd": "AD luôn vuông góc CD.",
        "dung": false
      }
    ]
  },
  {
    "id": "TG-V2-08",
    "vung": 2,
    "chuDe": "Tính chất hình thang cân",
    "dang": "can-tinh-chat",
    "muc": 1,
    "loai": "dung-sai",
    "de": "Cho hình thang cân ABCD có AB ∥ CD. Xác định đúng/sai:",
    "goiY": "Nhớ tính chất góc đáy và đường chéo.",
    "loiGiai": [
      "Hai góc kề mỗi đáy bằng nhau và hai đường chéo bằng nhau. Hai đáy không nhất thiết bằng nhau."
    ],
    "loiSai": "Đồng nhất “cân” với mọi cạnh đều bằng nhau.",
    "dapAnDuyet": "a Đ; b Đ; c Đ; d S",
    "y": [
      {
        "nd": "Góc A bằng góc B.",
        "dung": true
      },
      {
        "nd": "Góc C bằng góc D.",
        "dung": true
      },
      {
        "nd": "AC = BD.",
        "dung": true
      },
      {
        "nd": "AB = CD.",
        "dung": false
      }
    ]
  },
  {
    "id": "TG-V2-09",
    "vung": 2,
    "chuDe": "Tính chất và mệnh đề đảo",
    "dang": "can-nhan-biet",
    "muc": 3,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Phân biệt định lí với mệnh đề đảo; xem điều kiện hai đáy ở ví dụ trang 56.",
    "loiGiai": [
      "a là tính chất; c là dấu hiệu; d là định nghĩa. b sai: một hình có hai cặp cạnh đối song song, các góc 60°, 120°, 60°, 120° có hai cạnh bên bằng nhau nhưng hai góc cùng đáy không bằng nhau."
    ],
    "loiSai": "Đảo tính chất cạnh bên mà không xét điều kiện bổ sung.",
    "dapAnDuyet": "a Đ; b S; c Đ; d Đ",
    "y": [
      {
        "nd": "Hình thang cân có hai cạnh bên bằng nhau.",
        "dung": true
      },
      {
        "nd": "Mọi hình thang có hai cạnh bên bằng nhau đều là hình thang cân.",
        "dung": false
      },
      {
        "nd": "Hình thang có hai đường chéo bằng nhau là hình thang cân.",
        "dung": true
      },
      {
        "nd": "Hình thang có hai góc kề một đáy bằng nhau là hình thang cân.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V2-10",
    "vung": 2,
    "chuDe": "Quan hệ góc",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Hình thang cân ABCD có AB ∥ CD và A = 110°. Xác định đúng/sai:",
    "goiY": "Tính đủ bốn góc rồi xét từng ý.",
    "loiGiai": [
      "A = B = 110°; C = D = 180° − 110° = 70°. Suy ra A + C = 180°."
    ],
    "loiSai": "Nhầm hai góc đối bằng nhau như trong hình bình hành.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "B = 110°.",
        "dung": true
      },
      {
        "nd": "D = 70°.",
        "dung": true
      },
      {
        "nd": "C = 110°.",
        "dung": false
      },
      {
        "nd": "A + C = 180°.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V2-11",
    "vung": 2,
    "chuDe": "Tính góc đáy",
    "dang": "can-tinh-chat",
    "muc": 1,
    "loai": "dien",
    "de": "Hình thang cân ABCD có AB ∥ CD, góc D = 72°. Tính góc C, đơn vị độ.",
    "goiY": "C và D kề cùng đáy CD.",
    "loiGiai": [
      "Hai góc kề một đáy của hình thang cân bằng nhau nên C = D = 72°."
    ],
    "loiSai": "Lấy 180° − 72° dù hai góc cùng đáy.",
    "dapAnDuyet": "72",
    "dapAn": "72",
    "donVi": "°"
  },
  {
    "id": "TG-V2-12",
    "vung": 2,
    "chuDe": "Góc kề cạnh bên",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "dien",
    "de": "Hình thang cân ABCD có AB ∥ CD, góc A = 125°. Tính góc C, đơn vị độ.",
    "goiY": "A bù D; D bằng C.",
    "loiGiai": [
      "D = 180° − 125° = 55°; C = D = 55°."
    ],
    "loiSai": "Cho góc đối C bằng A.",
    "dapAnDuyet": "55",
    "dapAn": "55",
    "donVi": "°"
  },
  {
    "id": "TG-V2-13",
    "vung": 2,
    "chuDe": "Độ dài cạnh bên",
    "dang": "can-tinh-chat",
    "muc": 1,
    "loai": "dien",
    "de": "Hình thang cân ABCD có AB ∥ CD và AD = 7,5 cm. Tính BC, đơn vị cm.",
    "goiY": "Hai cạnh bên của hình thang cân bằng nhau.",
    "loiGiai": [
      "AD và BC là hai cạnh bên nên BC = AD = 7,5 cm."
    ],
    "loiSai": "Nhầm BC với một đáy.",
    "dapAnDuyet": "7,5",
    "dapAn": "7,5",
    "donVi": "cm"
  },
  {
    "id": "TG-V2-14",
    "vung": 2,
    "chuDe": "Độ dài đường chéo",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "dien",
    "de": "Hình thang cân ABCD có AC = 3x + 2 cm, BD = 5x − 6 cm. Tìm x.",
    "goiY": "Đặt hai độ dài đường chéo bằng nhau.",
    "loiGiai": [
      "AC = BD nên 3x + 2 = 5x − 6, suy ra 2x = 8 và x = 4. Khi đó cả hai đường chéo dài 14 cm."
    ],
    "loiSai": "Dùng tính chất hai đường chéo chia đôi nhau cho hình thang cân.",
    "dapAnDuyet": "4",
    "dapAn": "4",
    "donVi": ""
  },
  {
    "id": "TG-V2-15",
    "vung": 2,
    "chuDe": "Tổng độ dài các cạnh",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "dien",
    "de": "Một khung hình thang cân có hai đáy dài 8 cm và 14 cm, mỗi cạnh bên dài 5 cm. Tính tổng độ dài bốn cạnh, đơn vị cm.",
    "goiY": "Có hai cạnh bên cùng dài 5 cm.",
    "loiGiai": [
      "Tổng bốn cạnh bằng 8 + 14 + 5 + 5 = 32 cm."
    ],
    "loiSai": "Chỉ cộng một cạnh bên.",
    "dapAnDuyet": "32",
    "dapAn": "32",
    "donVi": "cm"
  },
  {
    "id": "TG-V2-16",
    "vung": 2,
    "chuDe": "So sánh góc giữa các hình",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Ba hình thang cân đều có đáy AB ∥ CD. Ở hình I, A = 105°; hình II, A = 120°; hình III, A = 95°. Xếp các thẻ góc D của hình II; góc D của hình III; góc D của hình I theo số đo tăng dần.",
    "goiY": "Mỗi hình đều có A + D = 180°.",
    "loiGiai": [
      "D của I, II, III lần lượt là 75°, 60°, 85°. Thứ tự tăng là II, I, III."
    ],
    "loiSai": "Dùng góc A thay cho góc D khi so sánh.",
    "dapAnDuyet": "D hình II → D hình I → D hình III",
    "nhan": [
      "D hình II",
      "D hình III",
      "D hình I"
    ],
    "so": [
      "60",
      "85",
      "75"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V2-17",
    "vung": 2,
    "chuDe": "So sánh độ dài",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Hình thang cân ABCD có AB ∥ CD; AB = 4 cm, AD = 13 cm, CD = 14 cm, AC = 15 cm. Xếp các thẻ CD; BC; BD; AB theo độ dài tăng dần.",
    "goiY": "Tìm BC và BD bằng tính chất hình thang cân.",
    "loiGiai": [
      "BC = AD = 13 cm; BD = AC = 15 cm. Vậy 4 < 13 < 14 < 15."
    ],
    "loiSai": "Nhầm cạnh bên với đường chéo hoặc cho hai đáy bằng nhau.",
    "dapAnDuyet": "AB → BC → CD → BD",
    "nhan": [
      "CD",
      "BC",
      "BD",
      "AB"
    ],
    "so": [
      "14",
      "13",
      "15",
      "4"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V2-18",
    "vung": 2,
    "chuDe": "Nhận diện cạnh bên",
    "dang": "thang-can",
    "muc": 1,
    "loai": "chon-hinh",
    "de": "Hình F2 biểu diễn hình thang cân ABCD có AB ∥ CD. Chọn cạnh bên cùng có đỉnh B với đáy AB. Các đối tượng chọn: AB, BC, CD, DA, AC, BD.",
    "goiY": "Xét các cạnh của tứ giác, không chọn đường chéo.",
    "loiGiai": [
      "Với hai đáy AB và CD, cạnh bên qua B là BC."
    ],
    "loiSai": "Chọn BD vì đoạn ấy cũng đi qua B.",
    "dapAnDuyet": "BC",
    "hinh": "F2",
    "doiTuong": [
      "AB",
      "BC",
      "CD",
      "DA",
      "AC",
      "BD"
    ],
    "dapAn": "BC"
  },
  {
    "id": "TG-V2-19",
    "vung": 2,
    "chuDe": "Nhận diện đường cao",
    "dang": "thang-can",
    "muc": 2,
    "loai": "chon-hinh",
    "de": "Trong hình F2, H thuộc CD và AH vuông góc CD. Chọn đoạn biểu diễn đường cao đã kẻ. Các đối tượng chọn: AD, BC, AC, BD, AH.",
    "goiY": "Đường cao nối hai đường thẳng chứa đáy và vuông góc với chúng.",
    "loiGiai": [
      "A nằm trên AB, H nằm trên CD, AH vuông góc CD nên AH là đường cao của hình thang."
    ],
    "loiSai": "Coi cạnh xiên AD là đường cao.",
    "dapAnDuyet": "AH",
    "hinh": "F2",
    "doiTuong": [
      "AD",
      "BC",
      "AC",
      "BD",
      "AH"
    ],
    "dapAn": "AH"
  },
  {
    "id": "TG-V2-20",
    "vung": 2,
    "chuDe": "Ghép yếu tố hình thang",
    "dang": "thang-can",
    "muc": 1,
    "loai": "ghep",
    "de": "Cho hình thang ABCD có AB ∥ CD và AH vuông góc CD tại H. Ghép mỗi đoạn với vai trò; mỗi nhãn dùng một lần.",
    "goiY": "Tên gọi dựa trên cặp đáy đã chọn.",
    "loiGiai": [
      "AB là đáy; AD là cạnh bên; AH nối hai đáy theo phương vuông góc nên là đường cao."
    ],
    "loiSai": "Đổi vai trò cạnh bên và đường cao.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "AB",
        "phai": "Đáy"
      },
      {
        "trai": "AD",
        "phai": "Cạnh bên"
      },
      {
        "trai": "AH",
        "phai": "Đường cao đã kẻ"
      }
    ]
  },
  {
    "id": "TG-V2-21",
    "vung": 2,
    "chuDe": "Ghép góc cần tìm",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "ghep",
    "de": "Mỗi trường hợp là hình thang cân ABCD có AB ∥ CD. Ghép với số đo C.",
    "goiY": "Trong hình thang cân, A + C = 180°.",
    "loiGiai": [
      "C lần lượt bằng 80°, 65°, 50° do A bù D và D = C."
    ],
    "loiSai": "Lấy C bằng A.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "A = 100°",
        "phai": "80°"
      },
      {
        "trai": "A = 115°",
        "phai": "65°"
      },
      {
        "trai": "A = 130°",
        "phai": "50°"
      }
    ]
  },
  {
    "id": "TG-V2-22",
    "vung": 2,
    "chuDe": "Phân loại phát biểu",
    "dang": "can-nhan-biet",
    "muc": 3,
    "loai": "ghep",
    "de": "Ghép mỗi phát biểu với vai trò chính trong bài Hình thang cân.",
    "goiY": "Xem phát biểu đang định nghĩa, suy ra tính chất hay nhận biết hình.",
    "loiGiai": [
      "1 định nghĩa tên hình; 2 xuất phát từ hình thang cân để suy ra tính chất; 3 dùng điều kiện đường chéo để kết luận hình thang cân."
    ],
    "loiSai": "Đánh đồng chiều thuận và chiều đảo của một định lí.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "Hình thang có hai góc kề một đáy bằng nhau được gọi là hình thang cân",
        "phai": "Định nghĩa"
      },
      {
        "trai": "Trong hình thang cân, hai cạnh bên bằng nhau",
        "phai": "Tính chất cạnh bên"
      },
      {
        "trai": "Hình thang có hai đường chéo bằng nhau là hình thang cân",
        "phai": "Dấu hiệu nhận biết theo đường chéo"
      }
    ]
  },
  {
    "id": "TG-V2-23",
    "vung": 2,
    "chuDe": "Lỗi góc đáy",
    "dang": "can-tinh-chat",
    "muc": 2,
    "loai": "bat-loi",
    "de": "Cho hình thang cân ABCD, AB ∥ CD, A = 120°. Tìm bước sai đầu tiên.",
    "goiY": "Tính chất chỉ nói hai góc kề cùng một đáy.",
    "loiGiai": [
      "Bước 1 đúng; B và C kề một cạnh bên nên bù nhau, C = 60°. Vì C = D nên D = 60°."
    ],
    "loiSai": "Hiểu “cân” là bốn góc bằng nhau.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "B = A = 120°.",
      "C = B = 120° vì hình thang cân có các góc bằng nhau.",
      "D = C = 120°."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V2-24",
    "vung": 2,
    "chuDe": "Lỗi dùng dấu hiệu",
    "dang": "can-nhan-biet",
    "muc": 3,
    "loai": "bat-loi",
    "de": "Cho tứ giác ABCD có AC = BD, chưa biết quan hệ song song nào. Tìm bước sai đầu tiên.",
    "goiY": "Dấu hiệu được áp dụng cho hình nào?",
    "loiGiai": [
      "Bước 1 là giả thiết. Bước 2 thiếu điều kiện ABCD là hình thang. Do đó không được suy ra hình thang cân hay cạnh bên bằng nhau."
    ],
    "loiSai": "Dùng dấu hiệu của hình thang cho tứ giác bất kỳ.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "Hai đường chéo của tứ giác bằng nhau.",
      "Suy ra ABCD là hình thang cân theo dấu hiệu đường chéo.",
      "Suy ra AD = BC."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V2-25",
    "vung": 2,
    "chuDe": "Chứng minh hình thang cân",
    "dang": "can-nhan-biet",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho tứ giác ABCD có AB ∥ CD và góc DAB = góc ABC. Sắp xếp các thẻ để chứng minh ABCD là hình thang cân.",
    "goiY": "Hai điều kiện đều phải có trước kết luận.",
    "loiGiai": [
      "P xác nhận hình thang; Q xác nhận hai góc kề đáy bằng nhau. P và Q độc lập, kết luận R phải sau cả hai."
    ],
    "loiSai": "Chỉ dùng điều kiện góc mà quên điều kiện hình thang.",
    "dapAnDuyet": "P → Q → R hoặc Q → P → R",
    "buoc": [
      "P: ABCD là hình thang với hai đáy AB và CD.",
      "Q: Hai góc DAB, ABC kề cùng đáy AB và bằng nhau theo giả thiết.",
      "R: Theo định nghĩa, ABCD là hình thang cân."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V2-26",
    "vung": 2,
    "chuDe": "Chứng minh bằng đường chéo",
    "dang": "can-nhan-biet",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho tứ giác ABCD có AB ∥ CD và AC = BD. Sắp xếp các thẻ dưới đây.",
    "goiY": "Cần cả điều kiện hình thang và điều kiện đường chéo.",
    "loiGiai": [
      "P, Q có thể đổi chỗ vì cùng xuất phát từ giả thiết. R chỉ được dùng sau khi cả hai điều kiện đã được xác nhận."
    ],
    "loiSai": "Đặt kết luận trước khi xác nhận đủ giả thiết.",
    "dapAnDuyet": "P → Q → R hoặc Q → P → R",
    "buoc": [
      "P: AC và BD là hai đường chéo bằng nhau theo giả thiết.",
      "Q: ABCD là hình thang do AB ∥ CD.",
      "R: Theo dấu hiệu đường chéo, ABCD là hình thang cân."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V3-01",
    "vung": 3,
    "chuDe": "Định nghĩa hình bình hành",
    "dang": "binh-hanh",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Tứ giác ABCD là hình bình hành theo định nghĩa khi nào?\n",
    "goiY": "Cần hai cặp cạnh đối song song.",
    "loiGiai": [
      "Theo định nghĩa, hình bình hành là tứ giác có các cạnh đối song song. Một cặp cạnh kề bằng nhau, hai đường chéo bằng nhau hoặc một góc vuông riêng lẻ đều chưa đủ."
    ],
    "loiSai": "Chỉ kiểm tra một cặp cạnh song song.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "AB ∥ CD và AD ∥ BC.",
      "AB = BC.",
      "AC = BD.",
      "Góc A = 90°."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V3-02",
    "vung": 3,
    "chuDe": "Tính chất cạnh",
    "dang": "binh-hanh",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Trong hình bình hành ABCD, cặp đoạn nào luôn bằng nhau?\n",
    "goiY": "Xét các cạnh đối.",
    "loiGiai": [
      "Hai cạnh đối AB và CD bằng nhau. Các cặp còn lại không nhất thiết bằng nhau."
    ],
    "loiSai": "Cho rằng hình bình hành có bốn cạnh bằng nhau.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "AB và BC.",
      "AB và CD.",
      "AC và BD.",
      "AB và AC."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V3-03",
    "vung": 3,
    "chuDe": "Tính chất góc",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Hình bình hành ABCD có góc A = 68°. Góc C bằng bao nhiêu?\n",
    "goiY": "A và C là hai góc đối.",
    "loiGiai": [
      "Các góc đối của hình bình hành bằng nhau nên C = A = 68°."
    ],
    "loiSai": "Lấy góc đối bù với A.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "112°.",
      "34°.",
      "68°.",
      "136°."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V3-04",
    "vung": 3,
    "chuDe": "Một cặp cạnh đối",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Điều kiện nào đủ để tứ giác ABCD là hình bình hành?\n",
    "goiY": "Cặp cạnh song song và bằng nhau phải là cùng một cặp cạnh đối.",
    "loiGiai": [
      "AB và CD là hai cạnh đối vừa song song vừa bằng nhau, nên ABCD là hình bình hành. Một cặp cạnh đối song song kèm hai cạnh bên bằng nhau, hai cặp cạnh kề bằng nhau hoặc hai đường chéo bằng nhau riêng lẻ đều chưa đủ."
    ],
    "loiSai": "Lấy tính song song ở một cặp, tính bằng nhau ở cặp khác.",
    "dapAnDuyet": "D",
    "phuongAn": [
      "AB ∥ CD và AD = BC.",
      "AB = BC và CD = DA.",
      "AC = BD.",
      "AB ∥ CD và AB = CD."
    ],
    "dapAn": "D"
  },
  {
    "id": "TG-V3-05",
    "vung": 3,
    "chuDe": "Hai đường chéo",
    "dang": "hbh-cheo",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Hai đường chéo AC và BD của hình bình hành ABCD cắt nhau tại O. Khẳng định nào luôn đúng?\n",
    "goiY": "Mỗi đường chéo bị chia đôi, không phải hai đường chéo bằng nhau.",
    "loiGiai": [
      "O là trung điểm của cả AC và BD nên OA = OC và OB = OD. Những đẳng thức còn lại cần thêm giả thiết."
    ],
    "loiSai": "Cho tất cả bốn đoạn từ O đến các đỉnh bằng nhau.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "OA = OC và OB = OD.",
      "OA = OB.",
      "AC vuông góc BD.",
      "AC = BD."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V3-06",
    "vung": 3,
    "chuDe": "Nhận biết theo góc",
    "dang": "hbh-nhan-biet",
    "muc": 3,
    "loai": "trac-nghiem",
    "de": "Tứ giác ABCD có bộ số đo góc nào dưới đây thì chắc chắn là hình bình hành?\nCác số trong mỗi phương án lần lượt ứng với A, B, C, D.",
    "goiY": "Kiểm tra cả hai cặp góc đối.",
    "loiGiai": [
      "Nếu A = C và B = D thì tứ giác có hai cặp góc đối bằng nhau, suy ra là hình bình hành. Các phương án khác không có đủ hai cặp góc đối bằng nhau."
    ],
    "loiSai": "Chỉ kiểm tra tổng bốn góc bằng 360°.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "70°, 110°, 80°, 100°.",
      "70°, 110°, 70°, 110°.",
      "80°, 80°, 100°, 100°.",
      "90°, 60°, 100°, 110°."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V3-07",
    "vung": 3,
    "chuDe": "Tính chất cơ bản",
    "dang": "binh-hanh",
    "muc": 1,
    "loai": "dung-sai",
    "de": "Cho hình bình hành ABCD. Xác định đúng/sai:",
    "goiY": "Hình bình hành không nhất thiết có góc vuông.",
    "loiGiai": [
      "a là định nghĩa; b và c là tính chất cạnh và góc đối. d chỉ đúng với trường hợp đặc biệt."
    ],
    "loiSai": "Nhầm hình bình hành với hình chữ nhật.",
    "dapAnDuyet": "a Đ; b Đ; c Đ; d S",
    "y": [
      {
        "nd": "AB ∥ CD.",
        "dung": true
      },
      {
        "nd": "AD = BC.",
        "dung": true
      },
      {
        "nd": "Góc A = góc C.",
        "dung": true
      },
      {
        "nd": "Mọi góc đều bằng 90°.",
        "dung": false
      }
    ]
  },
  {
    "id": "TG-V3-08",
    "vung": 3,
    "chuDe": "Giao điểm đường chéo",
    "dang": "hbh-cheo",
    "muc": 2,
    "loai": "dung-sai",
    "de": "AC và BD là hai đường chéo của hình bình hành ABCD, cắt nhau tại O. Xác định đúng/sai:",
    "goiY": "Ghép hai nửa thuộc cùng một đường chéo.",
    "loiGiai": [
      "O là trung điểm mỗi đường nên a, b, d đúng. Hai nửa của hai đường khác nhau chưa chắc bằng nhau nên c sai."
    ],
    "loiSai": "Đồng nhất “chia đôi nhau” với “bằng nhau”.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "OA = OC.",
        "dung": true
      },
      {
        "nd": "OB = OD.",
        "dung": true
      },
      {
        "nd": "OA = OD luôn đúng.",
        "dung": false
      },
      {
        "nd": "AC = 2OA.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V3-09",
    "vung": 3,
    "chuDe": "Dấu hiệu nhận biết",
    "dang": "hbh-nhan-biet",
    "muc": 3,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Chú ý “các cặp” và “một cặp”.",
    "loiGiai": [
      "a, c, d là các dấu hiệu trong SGK. b thiếu điều kiện song song cho cặp cạnh ấy hoặc thiếu cặp cạnh đối còn lại bằng nhau."
    ],
    "loiSai": "Lược mất một phần giả thiết của dấu hiệu.",
    "dapAnDuyet": "a Đ; b S; c Đ; d Đ",
    "y": [
      {
        "nd": "Tứ giác có các cạnh đối bằng nhau là hình bình hành.",
        "dung": true
      },
      {
        "nd": "Tứ giác có một cặp cạnh đối bằng nhau là hình bình hành.",
        "dung": false
      },
      {
        "nd": "Tứ giác có các góc đối bằng nhau là hình bình hành.",
        "dung": true
      },
      {
        "nd": "Tứ giác có hai đường chéo cắt nhau tại trung điểm mỗi đường là hình bình hành.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V3-10",
    "vung": 3,
    "chuDe": "Góc kề",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Hình bình hành ABCD có góc B = 118°. Xác định đúng/sai:",
    "goiY": "Góc đối bằng nhau, góc kề một cạnh bù nhau.",
    "loiGiai": [
      "D = B = 118°; A = C = 180° − 118° = 62°. Vì vậy c sai, ba ý còn lại đúng."
    ],
    "loiSai": "Dùng tính chất góc đối cho hai góc kề.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "D = 118°.",
        "dung": true
      },
      {
        "nd": "A = 62°.",
        "dung": true
      },
      {
        "nd": "C = 118°.",
        "dung": false
      },
      {
        "nd": "A + B = 180°.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V3-11",
    "vung": 3,
    "chuDe": "Tính cạnh đối",
    "dang": "binh-hanh",
    "muc": 1,
    "loai": "dien",
    "de": "Hình bình hành ABCD có AB = 8,4 cm. Tính CD, đơn vị cm.",
    "goiY": "AB đối với CD.",
    "loiGiai": [
      "Các cạnh đối bằng nhau nên CD = AB = 8,4 cm."
    ],
    "loiSai": "Chia đôi độ dài cạnh như đối với đường chéo.",
    "dapAnDuyet": "8,4",
    "dapAn": "8,4",
    "donVi": "cm"
  },
  {
    "id": "TG-V3-12",
    "vung": 3,
    "chuDe": "Tính góc kề",
    "dang": "binh-hanh",
    "muc": 1,
    "loai": "dien",
    "de": "Hình bình hành ABCD có A = 72°. Tính B, đơn vị độ.",
    "goiY": "A và B là hai góc kề một cạnh.",
    "loiGiai": [
      "A + B = 180° nên B = 180° − 72° = 108°."
    ],
    "loiSai": "Cho B bằng A.",
    "dapAnDuyet": "108",
    "dapAn": "108",
    "donVi": "°"
  },
  {
    "id": "TG-V3-13",
    "vung": 3,
    "chuDe": "Độ dài đường chéo",
    "dang": "hbh-cheo",
    "muc": 2,
    "loai": "dien",
    "de": "Hai đường chéo AC, BD của hình bình hành ABCD cắt nhau tại O. Biết OA = 4,5 cm. Tính AC, đơn vị cm.",
    "goiY": "O là trung điểm AC.",
    "loiGiai": [
      "AC = OA + OC = 2OA = 9 cm."
    ],
    "loiSai": "Lấy AC bằng OA.",
    "dapAnDuyet": "9",
    "dapAn": "9",
    "donVi": "cm"
  },
  {
    "id": "TG-V3-14",
    "vung": 3,
    "chuDe": "Hai biểu thức cạnh đối",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "dien",
    "de": "Hình bình hành ABCD có AB = 2x + 3 cm, CD = 5x − 6 cm. Tìm x.",
    "goiY": "Đặt AB bằng CD.",
    "loiGiai": [
      "2x + 3 = 5x − 6 nên 3x = 9, x = 3. Hai cạnh cùng dài 9 cm."
    ],
    "loiSai": "Dùng tổng hoặc tích hai biểu thức thay cho đẳng thức.",
    "dapAnDuyet": "3",
    "dapAn": "3",
    "donVi": ""
  },
  {
    "id": "TG-V3-15",
    "vung": 3,
    "chuDe": "Tổng độ dài các cạnh",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "dien",
    "de": "Tổng độ dài bốn cạnh hình bình hành ABCD là 38 cm; AB = 12 cm. Tính BC, đơn vị cm.",
    "goiY": "Hai cặp cạnh đối có độ dài bằng nhau.",
    "loiGiai": [
      "AB + BC = 38 : 2 = 19 cm. BC = 19 − 12 = 7 cm."
    ],
    "loiSai": "Lấy 38 − 12 thay vì nửa tổng trừ 12.",
    "dapAnDuyet": "7",
    "dapAn": "7",
    "donVi": "cm"
  },
  {
    "id": "TG-V3-16",
    "vung": 3,
    "chuDe": "So sánh góc",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Hình bình hành ABCD có A = 64°. Xếp các thẻ góc B; một nửa góc A; góc A theo số đo tăng dần.",
    "goiY": "Tính góc B và nửa góc A.",
    "loiGiai": [
      "B = 116°; A = 64°; nửa A = 32°. Vậy 32° < 64° < 116°."
    ],
    "loiSai": "Đưa hai góc bằng nhau vào thứ tự nghiêm ngặt hoặc nhầm góc bù.",
    "dapAnDuyet": "Một nửa A → A → B",
    "nhan": [
      "Góc B",
      "Một nửa góc A",
      "Góc A"
    ],
    "so": [
      "116",
      "32",
      "64"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V3-17",
    "vung": 3,
    "chuDe": "So sánh đoạn đường chéo",
    "dang": "hbh-cheo",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Hai đường chéo của hình bình hành ABCD cắt nhau tại O; AC = 18 cm, BD = 12 cm. Xếp các thẻ AC; OB; BD; OA theo độ dài tăng dần.",
    "goiY": "Mỗi đoạn từ O đến đỉnh bằng nửa đường chéo tương ứng.",
    "loiGiai": [
      "OB = 6 cm, OA = 9 cm, BD = 12 cm, AC = 18 cm. Thứ tự như đáp án."
    ],
    "loiSai": "Chia đôi nhầm đường chéo.",
    "dapAnDuyet": "OB → OA → BD → AC",
    "nhan": [
      "AC",
      "OB",
      "BD",
      "OA"
    ],
    "so": [
      "18",
      "6",
      "12",
      "9"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V3-18",
    "vung": 3,
    "chuDe": "Nhận diện cạnh đối",
    "dang": "binh-hanh",
    "muc": 1,
    "loai": "chon-hinh",
    "de": "Hình F3 là hình bình hành ABCD. Chọn cạnh đối với AD. Các đối tượng chọn: AB, BC, CD, DA, AC, BD.",
    "goiY": "Cạnh đối với AD không chứa A hoặc D.",
    "loiGiai": [
      "BC là cạnh đối với AD; AD ∥ BC và AD = BC theo tính chất hình bình hành."
    ],
    "loiSai": "Chọn AB vì nó kề AD.",
    "dapAnDuyet": "BC",
    "hinh": "F3",
    "doiTuong": [
      "AB",
      "BC",
      "CD",
      "DA",
      "AC",
      "BD"
    ],
    "dapAn": "BC"
  },
  {
    "id": "TG-V3-19",
    "vung": 3,
    "chuDe": "Trung điểm đường chéo",
    "dang": "hbh-cheo",
    "muc": 2,
    "loai": "chon-hinh",
    "de": "Hình F3 là hình bình hành ABCD; O là giao điểm hai đường chéo. Chọn đoạn còn lại của đường chéo AC có độ dài bằng OA. Các đối tượng chọn: OB, OC, OD, AB, BC.",
    "goiY": "Chỉ xét đường chéo AC.",
    "loiGiai": [
      "O là trung điểm AC nên OA = OC; OC là đoạn thỏa yêu cầu. Không dùng hình vẽ để kết luận OA bằng các đoạn khác."
    ],
    "loiSai": "Chọn OB do nhìn hình tưởng hai đường chéo bằng nhau.",
    "dapAnDuyet": "OC",
    "hinh": "F3",
    "doiTuong": [
      "OB",
      "OC",
      "OD",
      "AB",
      "BC"
    ],
    "dapAn": "OC"
  },
  {
    "id": "TG-V3-20",
    "vung": 3,
    "chuDe": "Ghép góc kề",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "ghep",
    "de": "Mỗi trường hợp là hình bình hành ABCD. Ghép góc A với góc B.",
    "goiY": "A + B = 180°.",
    "loiGiai": [
      "Các góc B tương ứng bằng 130°, 105°, 70°."
    ],
    "loiSai": "Ghép hai góc bằng nhau thay vì bù nhau.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "A = 50°",
        "phai": "B = 130°"
      },
      {
        "trai": "A = 75°",
        "phai": "B = 105°"
      },
      {
        "trai": "A = 110°",
        "phai": "B = 70°"
      }
    ]
  },
  {
    "id": "TG-V3-21",
    "vung": 3,
    "chuDe": "Ghép đường chéo",
    "dang": "hbh-cheo",
    "muc": 1,
    "loai": "ghep",
    "de": "Trong mỗi trường hợp, O là giao điểm hai đường chéo hình bình hành ABCD. Ghép dữ kiện với độ dài cần tìm.",
    "goiY": "O chia đôi từng đường chéo.",
    "loiGiai": [
      "OA = 14 : 2 = 7; OD = 10 : 2 = 5; BD = 2 × 6 = 12 cm."
    ],
    "loiSai": "Nhân đôi ở trường hợp cần chia đôi.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "AC = 14 cm, tìm OA",
        "phai": "7 cm"
      },
      {
        "trai": "BD = 10 cm, tìm OD",
        "phai": "5 cm"
      },
      {
        "trai": "OB = 6 cm, tìm BD",
        "phai": "12 cm"
      }
    ]
  },
  {
    "id": "TG-V3-22",
    "vung": 3,
    "chuDe": "Ghép dấu hiệu",
    "dang": "hbh-nhan-biet",
    "muc": 2,
    "loai": "ghep",
    "de": "Ghép dữ kiện của tứ giác ABCD với dấu hiệu hình bình hành được áp dụng trực tiếp.",
    "goiY": "Nhìn loại yếu tố xuất hiện trong giả thiết.",
    "loiGiai": [
      "1 xét cả hai cặp cạnh đối; 2 xét cùng một cặp cạnh; 3 xác nhận O là trung điểm cả hai đường chéo."
    ],
    "loiSai": "Dùng tên dấu hiệu không khớp giả thiết.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "AB = CD, AD = BC",
        "phai": "Các cạnh đối bằng nhau"
      },
      {
        "trai": "AB ∥ CD, AB = CD",
        "phai": "Một cặp cạnh đối vừa song song vừa bằng nhau"
      },
      {
        "trai": "O thuộc AC và BD, OA = OC, OB = OD",
        "phai": "Hai đường chéo cắt nhau tại trung điểm mỗi đường"
      }
    ]
  },
  {
    "id": "TG-V3-23",
    "vung": 3,
    "chuDe": "Lỗi điều kiện nhận biết",
    "dang": "hbh-nhan-biet",
    "muc": 3,
    "loai": "bat-loi",
    "de": "Cho tứ giác ABCD có AB ∥ CD và AD = BC. Tìm bước sai đầu tiên.",
    "goiY": "Hai điều kiện đang nói về cùng một cặp cạnh hay hai cặp khác nhau?",
    "loiGiai": [
      "Giả thiết song song thuộc AB, CD; bằng nhau thuộc AD, BC. Không đủ để khẳng định có một cặp cạnh đối vừa song song vừa bằng nhau."
    ],
    "loiSai": "Ghép hai điều kiện của hai cặp cạnh khác nhau thành một dấu hiệu.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "AB và CD là một cặp cạnh đối song song.",
      "ABCD có một cặp cạnh đối vừa song song vừa bằng nhau.",
      "ABCD là hình bình hành."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V3-24",
    "vung": 3,
    "chuDe": "Lỗi đường chéo",
    "dang": "hbh-cheo",
    "muc": 2,
    "loai": "bat-loi",
    "de": "Cho hình bình hành ABCD, AC và BD cắt nhau tại O; AC = 16 cm, BD = 10 cm. Tìm bước sai đầu tiên.",
    "goiY": "Chia đôi nhau không có nghĩa bằng nhau.",
    "loiGiai": [
      "Bước 1 đúng. OB = OD = BD : 2 = 5 cm; không bằng OA. Bước sai đầu tiên là bước 2."
    ],
    "loiSai": "Coi bốn nửa đường chéo đều bằng nhau.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "OA = OC = 8 cm.",
      "OB = OA = 8 cm vì hai đường chéo chia đôi nhau.",
      "OD = OB = 8 cm."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V3-25",
    "vung": 3,
    "chuDe": "Chứng minh theo cạnh",
    "dang": "binh-hanh",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho hình bình hành ABCD; E, F lần lượt là trung điểm AB, CD. Chứng minh AE = CF. Sắp xếp các thẻ dưới đây.",
    "goiY": "Hai bước đầu xuất phát độc lập từ giả thiết.",
    "loiGiai": [
      "P cho các nửa cạnh; Q cho hai cạnh đối bằng nhau. Kết hợp được R. Không dùng định lí đường trung bình."
    ],
    "loiSai": "Viện dẫn đường trung bình dù không cần thiết; bắt buộc thứ tự giữa P và Q.",
    "dapAnDuyet": "P → Q → R hoặc Q → P → R",
    "buoc": [
      "P: AE = AB/2 và CF = CD/2 theo định nghĩa trung điểm.",
      "Q: AB = CD theo tính chất hình bình hành.",
      "R: Từ hai kết quả trên suy ra AE = CF."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V3-26",
    "vung": 3,
    "chuDe": "Chứng minh theo đường chéo",
    "dang": "hbh-cheo",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho tứ giác ABCD có hai đường chéo cắt nhau tại O; OA = OC, OB = OD. Sắp xếp để chứng minh AB ∥ CD.",
    "goiY": "Từ trung điểm đi đến nhận biết hình rồi lấy tính chất cần có.",
    "loiGiai": [
      "Các đẳng thức cùng điều kiện O thuộc hai đường chéo cho P; P suy ra Q; Q cho R. Thứ tự phụ thuộc là duy nhất."
    ],
    "loiSai": "Kết luận song song trước khi lập luận được hình bình hành.",
    "dapAnDuyet": "P → Q → R; chỉ chấp nhận thứ tự này",
    "buoc": [
      "P: O là trung điểm cả AC và BD.",
      "Q: ABCD là hình bình hành theo dấu hiệu đường chéo.",
      "R: Suy ra AB ∥ CD theo định nghĩa hình bình hành."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2
      ]
    ]
  },
  {
    "id": "TG-V4-01",
    "vung": 4,
    "chuDe": "Định nghĩa hình chữ nhật",
    "dang": "chu-nhat",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Điều kiện nào là định nghĩa hình chữ nhật?\n",
    "goiY": "Định nghĩa đặt điều kiện cho cả bốn góc.",
    "loiGiai": [
      "Hình chữ nhật là tứ giác có bốn góc vuông. Các điều kiện trong ba phương án còn lại riêng lẻ chưa đủ."
    ],
    "loiSai": "Bỏ bớt số góc vuông trong định nghĩa.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "Tứ giác có hai cạnh bằng nhau.",
      "Tứ giác có bốn góc vuông.",
      "Tứ giác có hai đường chéo bằng nhau.",
      "Tứ giác có một góc vuông."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V4-02",
    "vung": 4,
    "chuDe": "Tính chất đường chéo",
    "dang": "hcn-cheo",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Trong hình chữ nhật ABCD, hai đường chéo AC và BD cắt nhau tại O. Khẳng định nào luôn đúng?\n",
    "goiY": "Kết hợp đường chéo bằng nhau và chia đôi nhau.",
    "loiGiai": [
      "AC = BD; O là trung điểm mỗi đường nên bốn nửa đường chéo bằng nhau. Các khẳng định còn lại không đúng với mọi hình chữ nhật."
    ],
    "loiSai": "Gán tính chất của hình vuông cho mọi hình chữ nhật.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "AC vuông góc BD.",
      "AB = BC.",
      "OA = OB = OC = OD.",
      "AC là phân giác góc DAB."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V4-03",
    "vung": 4,
    "chuDe": "Dấu hiệu theo góc",
    "dang": "chu-nhat",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Cho ABCD là hình bình hành. Thêm điều kiện nào dưới đây để chắc chắn ABCD là hình chữ nhật?\n",
    "goiY": "Chọn điều kiện mới, không phải tính chất vốn có của hình bình hành.",
    "loiGiai": [
      "Hình bình hành có một góc vuông là hình chữ nhật. Các điều kiện trong ba phương án còn lại đều đã đúng với mọi hình bình hành nên chưa đủ."
    ],
    "loiSai": "Chọn một tính chất chung của hình bình hành làm điều kiện bổ sung.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "Góc A = 90°.",
      "AB = CD.",
      "AD ∥ BC.",
      "Hai đường chéo cắt nhau tại trung điểm mỗi đường."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V4-04",
    "vung": 4,
    "chuDe": "Dấu hiệu theo đường chéo",
    "dang": "hcn-cheo",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Cho ABCD là hình bình hành. Điều kiện nào đủ để nhận biết hình chữ nhật theo đường chéo?\n",
    "goiY": "Hình bình hành đã có hai đường chéo chia đôi nhau.",
    "loiGiai": [
      "Hai đường chéo bằng nhau là điều kiện bổ sung đủ để một hình bình hành là hình chữ nhật. Các điều kiện còn lại vốn có ở mọi hình bình hành."
    ],
    "loiSai": "Nhầm “bằng nhau” với “chia đôi nhau”.",
    "dapAnDuyet": "D",
    "phuongAn": [
      "OA = OC, với O là giao điểm đường chéo.",
      "OB = OD.",
      "AC và BD cắt nhau.",
      "AC = BD."
    ],
    "dapAn": "D"
  },
  {
    "id": "TG-V4-05",
    "vung": 4,
    "chuDe": "Trung tuyến tam giác vuông",
    "dang": "trung-tuyen",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Tam giác ABC vuông tại A; M là trung điểm BC và BC = 18 cm. AM bằng bao nhiêu?\n",
    "goiY": "AM là trung tuyến ứng với cạnh huyền.",
    "loiGiai": [
      "Trong tam giác vuông, trung tuyến ứng với cạnh huyền bằng nửa cạnh huyền. AM = 18 : 2 = 9 cm."
    ],
    "loiSai": "Lấy trung tuyến bằng cả cạnh huyền.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "18 cm.",
      "9 cm.",
      "6 cm.",
      "36 cm."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V4-06",
    "vung": 4,
    "chuDe": "Nhận xét đảo về trung tuyến",
    "dang": "trung-tuyen",
    "muc": 3,
    "loai": "trac-nghiem",
    "de": "Tam giác ABC có M là trung điểm BC và AM = BC/2. Kết luận nào chắc chắn đúng?\n",
    "goiY": "Góc vuông đối diện cạnh ứng với trung tuyến đặc biệt.",
    "loiGiai": [
      "AM là trung tuyến ứng với BC và bằng BC/2, nên tam giác vuông tại đỉnh A. Không có điều kiện buộc AB = AC."
    ],
    "loiSai": "Đặt góc vuông ở đầu mút của cạnh BC.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "Góc B = 90°.",
      "Góc C = 90°.",
      "Góc A = 90°.",
      "AB = AC."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V4-07",
    "vung": 4,
    "chuDe": "Định nghĩa và tính chất",
    "dang": "chu-nhat",
    "muc": 1,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Dùng tổng góc tứ giác và tính chất hình chữ nhật.",
    "loiGiai": [
      "a, b đúng. c không bắt buộc. d đúng vì góc thứ tư bằng 360° − 270° = 90°, đủ bốn góc vuông."
    ],
    "loiSai": "Nhầm bốn góc bằng nhau với bốn cạnh bằng nhau.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "Mọi hình chữ nhật là hình bình hành.",
        "dung": true
      },
      {
        "nd": "Hình chữ nhật có các cạnh đối bằng nhau.",
        "dung": true
      },
      {
        "nd": "Hình chữ nhật luôn có bốn cạnh bằng nhau.",
        "dung": false
      },
      {
        "nd": "Tứ giác có ba góc vuông là hình chữ nhật.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V4-08",
    "vung": 4,
    "chuDe": "Các nửa đường chéo",
    "dang": "hcn-cheo",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Hình chữ nhật ABCD có AC, BD cắt nhau tại O và AC = 14 cm. Xác định đúng/sai:",
    "goiY": "Mỗi đường chéo dài 14 cm; mỗi nửa dài 7 cm.",
    "loiGiai": [
      "AC = BD = 14 cm; OA = OB = OC = OD = 7 cm. Các kết luận a, b, d đúng; c sai."
    ],
    "loiSai": "Đồng nhất nửa đường chéo với cả đường chéo.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "BD = 14 cm.",
        "dung": true
      },
      {
        "nd": "OB = 7 cm.",
        "dung": true
      },
      {
        "nd": "OD = 14 cm.",
        "dung": false
      },
      {
        "nd": "OA + OC = 14 cm.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V4-09",
    "vung": 4,
    "chuDe": "Điều kiện đủ",
    "dang": "chu-nhat",
    "muc": 3,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Ở c, cần nhận biết hình bình hành trước.",
    "loiGiai": [
      "a thiếu điều kiện; hình thang cân không vuông là phản ví dụ. b, d là dấu hiệu. c: đường chéo chia đôi nhau cho hình bình hành; thêm bằng nhau cho hình chữ nhật."
    ],
    "loiSai": "Lược bỏ giả thiết hình bình hành.",
    "dapAnDuyet": "a S; b Đ; c Đ; d Đ",
    "y": [
      {
        "nd": "Tứ giác có hai đường chéo bằng nhau là hình chữ nhật.",
        "dung": false
      },
      {
        "nd": "Hình bình hành có hai đường chéo bằng nhau là hình chữ nhật.",
        "dung": true
      },
      {
        "nd": "Tứ giác có hai đường chéo bằng nhau và cắt nhau tại trung điểm mỗi đường là hình chữ nhật.",
        "dung": true
      },
      {
        "nd": "Hình bình hành có một góc vuông là hình chữ nhật.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V4-10",
    "vung": 4,
    "chuDe": "Trung tuyến và cạnh huyền",
    "dang": "trung-tuyen",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Tam giác ABC vuông tại A, M là trung điểm BC. Xác định đúng/sai:",
    "goiY": "AM, BM và CM đều bằng nửa BC.",
    "loiGiai": [
      "AM = BC/2 theo tính chất trung tuyến; BM = CM = BC/2 theo trung điểm. Vì BC > 0 nên AM không bằng BC; AM = 6 thì BC = 12 cm."
    ],
    "loiSai": "Bỏ hệ số một phần hai.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "AM = BM.",
        "dung": true
      },
      {
        "nd": "AM = CM.",
        "dung": true
      },
      {
        "nd": "AM = BC.",
        "dung": false
      },
      {
        "nd": "Nếu AM = 6 cm thì BC = 12 cm.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V4-11",
    "vung": 4,
    "chuDe": "Góc thứ tư",
    "dang": "chu-nhat",
    "muc": 1,
    "loai": "dien",
    "de": "Tứ giác ABCD có A = B = C = 90°. Tính góc D, đơn vị độ.",
    "goiY": "Tổng góc tứ giác bằng 360°.",
    "loiGiai": [
      "D = 360° − 3 × 90° = 90°. Tứ giác có bốn góc vuông."
    ],
    "loiSai": "Cho rằng chưa đủ dữ kiện để xác định góc còn lại.",
    "dapAnDuyet": "90",
    "dapAn": "90",
    "donVi": "°"
  },
  {
    "id": "TG-V4-12",
    "vung": 4,
    "chuDe": "Nửa đường chéo",
    "dang": "hcn-cheo",
    "muc": 1,
    "loai": "dien",
    "de": "Hình chữ nhật ABCD có hai đường chéo cắt nhau tại O, AC = 17 cm. Tính OB, đơn vị cm.",
    "goiY": "BD = AC và O là trung điểm BD.",
    "loiGiai": [
      "BD = 17 cm; OB = BD/2 = 8,5 cm."
    ],
    "loiSai": "Tính OB bằng 17 cm hoặc chỉ xét AC mà không liên hệ BD.",
    "dapAnDuyet": "8,5",
    "dapAn": "8,5",
    "donVi": "cm"
  },
  {
    "id": "TG-V4-13",
    "vung": 4,
    "chuDe": "Đường chéo qua biểu thức",
    "dang": "hcn-cheo",
    "muc": 2,
    "loai": "dien",
    "de": "Hình chữ nhật ABCD có AC = 4x − 1 cm và BD = 2x + 7 cm. Tìm x.",
    "goiY": "Hai đường chéo bằng nhau.",
    "loiGiai": [
      "4x − 1 = 2x + 7 nên 2x = 8, x = 4. Cả hai đường chéo dài 15 cm."
    ],
    "loiSai": "Dùng quan hệ vuông góc để lập phương trình độ dài.",
    "dapAnDuyet": "4",
    "dapAn": "4",
    "donVi": ""
  },
  {
    "id": "TG-V4-14",
    "vung": 4,
    "chuDe": "Trung tuyến ứng với cạnh huyền",
    "dang": "trung-tuyen",
    "muc": 2,
    "loai": "dien",
    "de": "Tam giác PQR vuông tại P, M là trung điểm QR; PM = 6,5 cm. Tính QR, đơn vị cm.",
    "goiY": "Cạnh huyền gấp đôi trung tuyến tương ứng.",
    "loiGiai": [
      "PM = QR/2 nên QR = 2 × 6,5 = 13 cm."
    ],
    "loiSai": "Chia 6,5 cho 2 thay vì nhân 2.",
    "dapAnDuyet": "13",
    "dapAn": "13",
    "donVi": "cm"
  },
  {
    "id": "TG-V4-15",
    "vung": 4,
    "chuDe": "Hai cạnh hình chữ nhật",
    "dang": "chu-nhat",
    "muc": 3,
    "loai": "dien",
    "de": "Hình chữ nhật ABCD có tổng độ dài bốn cạnh bằng 46 cm; AB dài hơn BC 5 cm. Tính BC, đơn vị cm.",
    "goiY": "Tìm tổng AB + BC rồi dùng hiệu.",
    "loiGiai": [
      "AB + BC = 23; AB = BC + 5. Suy ra 2BC = 18, BC = 9 cm, AB = 14 cm."
    ],
    "loiSai": "Dùng 46 làm tổng hai cạnh kề hoặc quên chia đôi sau khi trừ hiệu.",
    "dapAnDuyet": "9",
    "dapAn": "9",
    "donVi": "cm"
  },
  {
    "id": "TG-V4-16",
    "vung": 4,
    "chuDe": "So sánh các đoạn",
    "dang": "hcn-cheo",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Hình chữ nhật ABCD có hai đường chéo cắt nhau tại O; AB = 8 cm, BC = 6 cm, AC = 10 cm. Xếp các thẻ AC; AB; OA; BC theo độ dài tăng dần.",
    "goiY": "Chỉ cần tính OA từ AC; không phải tính đường chéo từ các cạnh.",
    "loiGiai": [
      "OA = AC/2 = 5 cm. Vậy 5 < 6 < 8 < 10."
    ],
    "loiSai": "Cho OA bằng một cạnh hoặc tự thêm công thức không cần thiết.",
    "dapAnDuyet": "OA → BC → AB → AC",
    "nhan": [
      "AC",
      "AB",
      "OA",
      "BC"
    ],
    "so": [
      "10",
      "8",
      "5",
      "6"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V4-17",
    "vung": 4,
    "chuDe": "So sánh trung tuyến",
    "dang": "trung-tuyen",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Ba tam giác vuông I, II, III có cạnh huyền lần lượt dài 12 cm, 18 cm, 10 cm. Xếp trung tuyến ứng với cạnh huyền của ba tam giác theo độ dài giảm dần.",
    "goiY": "Mỗi trung tuyến bằng nửa cạnh huyền của tam giác đó.",
    "loiGiai": [
      "Ba trung tuyến dài 6 cm, 9 cm, 5 cm. Giảm dần: 9 > 6 > 5."
    ],
    "loiSai": "Đọc nhầm yêu cầu giảm dần.",
    "dapAnDuyet": "Trung tuyến II → trung tuyến I → trung tuyến III",
    "nhan": [
      "Trung tuyến I",
      "Trung tuyến II",
      "Trung tuyến III"
    ],
    "so": [
      "6",
      "9",
      "5"
    ],
    "chieu": "giam"
  },
  {
    "id": "TG-V4-18",
    "vung": 4,
    "chuDe": "Nhận diện đường chéo",
    "dang": "hcn-cheo",
    "muc": 1,
    "loai": "chon-hinh",
    "de": "Hình F4 là hình chữ nhật ABCD. Chọn đường chéo khác AC có độ dài bằng AC. Các đối tượng chọn: AB, BC, CD, DA, BD.",
    "goiY": "Hình chữ nhật có hai đường chéo bằng nhau.",
    "loiGiai": [
      "Hai đường chéo là AC và BD; BD là đường chéo còn lại và BD = AC."
    ],
    "loiSai": "Chọn cạnh dài nhất nhìn thấy thay vì xác định đường chéo.",
    "dapAnDuyet": "BD",
    "hinh": "F4",
    "doiTuong": [
      "AB",
      "BC",
      "CD",
      "DA",
      "BD"
    ],
    "dapAn": "BD"
  },
  {
    "id": "TG-V4-19",
    "vung": 4,
    "chuDe": "Nhận diện nửa đường chéo",
    "dang": "hcn-cheo",
    "muc": 2,
    "loai": "chon-hinh",
    "de": "Hình F4 là hình chữ nhật ABCD, O là giao điểm đường chéo. Chọn đoạn thuộc BD, có một đầu tại B và dài bằng nửa AC. Các đối tượng chọn: OA, OB, OC, OD, AB.",
    "goiY": "Dùng BD = AC và OB = BD/2.",
    "loiGiai": [
      "OB nằm trên BD, có đầu B; O là trung điểm BD nên OB = BD/2 = AC/2. Các đoạn khác không thỏa đồng thời yêu cầu vị trí."
    ],
    "loiSai": "Chỉ xét độ dài, bỏ qua điều kiện có đầu tại B.",
    "dapAnDuyet": "OB",
    "hinh": "F4",
    "doiTuong": [
      "OA",
      "OB",
      "OC",
      "OD",
      "AB"
    ],
    "dapAn": "OB"
  },
  {
    "id": "TG-V4-20",
    "vung": 4,
    "chuDe": "Ghép dữ kiện đường chéo",
    "dang": "hcn-cheo",
    "muc": 1,
    "loai": "ghep",
    "de": "Mỗi trường hợp là hình chữ nhật ABCD với giao điểm đường chéo O. Ghép với độ dài cần tìm.",
    "goiY": "Hai đường chéo bằng nhau và chia đôi nhau.",
    "loiGiai": [
      "OB = 10 cm; BD = AC = 14 cm; OC = AC/2 = 9 cm."
    ],
    "loiSai": "Nhân hoặc chia hai sai chiều.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "AC = 20 cm, tìm OB",
        "phai": "10 cm"
      },
      {
        "trai": "OA = 7 cm, tìm BD",
        "phai": "14 cm"
      },
      {
        "trai": "BD = 18 cm, tìm OC",
        "phai": "9 cm"
      }
    ]
  },
  {
    "id": "TG-V4-21",
    "vung": 4,
    "chuDe": "Ghép tam giác vuông",
    "dang": "trung-tuyen",
    "muc": 2,
    "loai": "ghep",
    "de": "Tam giác ABC vuông tại A, M là trung điểm BC. Mỗi dòng là một trường hợp riêng. Ghép với kết quả cần tìm.",
    "goiY": "AM = BM = CM = BC/2.",
    "loiGiai": [
      "Lần lượt AM = 7,5 cm; BC = 16 cm; AM = BM = 6 cm."
    ],
    "loiSai": "Không nhận ra BM cũng bằng nửa cạnh huyền.",
    "dapAnDuyet": "1-c; 2-b; 3-a",
    "cap": [
      {
        "trai": "BC = 15 cm, tìm AM",
        "phai": "7,5 cm"
      },
      {
        "trai": "AM = 8 cm, tìm BC",
        "phai": "16 cm"
      },
      {
        "trai": "BM = 6 cm, tìm AM",
        "phai": "6 cm"
      }
    ]
  },
  {
    "id": "TG-V4-22",
    "vung": 4,
    "chuDe": "Ghép căn cứ nhận biết",
    "dang": "chu-nhat",
    "muc": 2,
    "loai": "ghep",
    "de": "Ghép giả thiết với cách nhận biết hình chữ nhật trực tiếp nhất.",
    "goiY": "Đọc đúng giả thiết đứng trước mỗi điều kiện.",
    "loiGiai": [
      "1, 2 là hai dấu hiệu từ hình bình hành; 3 chính là định nghĩa. Mỗi nhãn ứng với một căn cứ khác nhau."
    ],
    "loiSai": "Gọi mọi lập luận là định nghĩa mà không phân biệt dấu hiệu.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "Hình bình hành có góc A vuông",
        "phai": "Dùng dấu hiệu một góc vuông"
      },
      {
        "trai": "Hình bình hành có AC = BD",
        "phai": "Dùng dấu hiệu hai đường chéo bằng nhau"
      },
      {
        "trai": "Tứ giác có bốn góc vuông",
        "phai": "Dùng định nghĩa hình chữ nhật"
      }
    ]
  },
  {
    "id": "TG-V4-23",
    "vung": 4,
    "chuDe": "Lỗi dùng dấu hiệu",
    "dang": "chu-nhat",
    "muc": 3,
    "loai": "bat-loi",
    "de": "Cho tứ giác ABCD có AC = BD = 12 cm. Tìm bước sai đầu tiên.",
    "goiY": "Đề đã cho hoặc đã chứng minh hình bình hành chưa?",
    "loiGiai": [
      "Chưa có điều kiện hình bình hành hay đường chéo chia đôi nhau. Chỉ AC = BD không đủ suy ra hình chữ nhật. Bước 2 là lỗi đầu tiên."
    ],
    "loiSai": "Bỏ qua giả thiết của dấu hiệu nhận biết.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "Hai đường chéo của ABCD bằng nhau.",
      "Suy ra ABCD là hình chữ nhật.",
      "Suy ra góc A = 90°."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V4-24",
    "vung": 4,
    "chuDe": "Lỗi trung tuyến",
    "dang": "trung-tuyen",
    "muc": 2,
    "loai": "bat-loi",
    "de": "Tam giác ABC vuông tại A, M là trung điểm BC; BC = 24 cm. Tìm bước sai đầu tiên.",
    "goiY": "Nhớ hệ số trong tính chất trung tuyến.",
    "loiGiai": [
      "Bước 1 đúng. AM = BC/2 = 12 cm, không phải 24 cm; BM cũng bằng 12 cm."
    ],
    "loiSai": "Nhớ nhầm trung tuyến bằng cạnh huyền.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "AM là trung tuyến ứng với cạnh huyền.",
      "AM = BC = 24 cm.",
      "BM = AM = 24 cm."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V4-25",
    "vung": 4,
    "chuDe": "Chứng minh hình chữ nhật",
    "dang": "chu-nhat",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho tứ giác ABCD có AC và BD cắt nhau tại O; OA = OC, OB = OD, AC = BD. Sắp xếp các thẻ dưới đây.",
    "goiY": "Chứng minh hình bình hành trước khi dùng dấu hiệu hình chữ nhật.",
    "loiGiai": [
      "Q xác nhận hai trung điểm; P nhận biết hình bình hành; R dùng thêm hai đường chéo bằng nhau. Các bước phụ thuộc theo chuỗi."
    ],
    "loiSai": "Bỏ bước chứng minh hình bình hành.",
    "dapAnDuyet": "Q → P → R; chỉ chấp nhận thứ tự này",
    "buoc": [
      "P: ABCD là hình bình hành theo dấu hiệu đường chéo.",
      "Q: O là trung điểm của cả AC và BD.",
      "R: Hình bình hành ABCD có AC = BD theo giả thiết nên là hình chữ nhật."
    ],
    "thuTuDung": [
      [
        1,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V4-26",
    "vung": 4,
    "chuDe": "Chứng minh các đoạn bằng nhau",
    "dang": "hcn-cheo",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho hình chữ nhật ABCD có AC và BD cắt nhau tại O. Chứng minh OA = OB. Sắp xếp các thẻ dưới đây.",
    "goiY": "Hai tính chất P, Q đều xuất phát trực tiếp từ giả thiết.",
    "loiGiai": [
      "P và Q độc lập và cùng cần cho kết luận R; chấp nhận cả hai thứ tự hợp lí."
    ],
    "loiSai": "Chỉ dùng tính chất chia đôi nhau mà quên AC = BD.",
    "dapAnDuyet": "P → Q → R hoặc Q → P → R",
    "buoc": [
      "P: AC = BD theo tính chất hình chữ nhật.",
      "Q: OA = AC/2 và OB = BD/2 do O là trung điểm hai đường chéo.",
      "R: Từ hai kết quả trên suy ra OA = OB."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V5-01",
    "vung": 5,
    "chuDe": "Định nghĩa hình thoi",
    "dang": "hinh-thoi",
    "muc": 1,
    "loai": "trac-nghiem",
    "de": "Điều kiện nào là định nghĩa hình thoi?\n",
    "goiY": "Định nghĩa yêu cầu độ dài của cả bốn cạnh.",
    "loiGiai": [
      "Hình thoi là tứ giác có bốn cạnh bằng nhau. Ba điều kiện còn lại riêng lẻ chưa đủ."
    ],
    "loiSai": "Chỉ kiểm tra một cặp cạnh kề.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "Tứ giác có bốn cạnh bằng nhau.",
      "Tứ giác có hai đường chéo bằng nhau.",
      "Tứ giác có hai cạnh kề bằng nhau.",
      "Tứ giác có một góc vuông."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V5-02",
    "vung": 5,
    "chuDe": "Nhận biết hình thoi",
    "dang": "hinh-thoi",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Cho ABCD là hình bình hành. Điều kiện nào dưới đây đủ để kết luận ABCD là hình thoi?\n",
    "goiY": "Tìm dấu hiệu hình thoi theo đường chéo.",
    "loiGiai": [
      "Hình bình hành có hai đường chéo vuông góc là hình thoi. Hai đường chéo bằng nhau hoặc một góc vuông chỉ bảo đảm hình chữ nhật; AB = CD vốn có ở mọi hình bình hành."
    ],
    "loiSai": "Nhầm dấu hiệu hình chữ nhật với dấu hiệu hình thoi.",
    "dapAnDuyet": "C",
    "phuongAn": [
      "AC = BD.",
      "Góc A = 90°.",
      "AC vuông góc BD.",
      "AB = CD."
    ],
    "dapAn": "C"
  },
  {
    "id": "TG-V5-03",
    "vung": 5,
    "chuDe": "Nhận biết hình vuông",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "trac-nghiem",
    "de": "Cho ABCD là hình chữ nhật. Bổ sung điều kiện nào để chắc chắn ABCD là hình vuông?\n",
    "goiY": "Hình chữ nhật cần thêm điều kiện về hai cạnh kề.",
    "loiGiai": [
      "Hình chữ nhật có hai cạnh kề bằng nhau là hình vuông. Các điều kiện còn lại đã đúng với mọi hình chữ nhật."
    ],
    "loiSai": "Chọn tính chất vốn có làm điều kiện bổ sung.",
    "dapAnDuyet": "B",
    "phuongAn": [
      "AB = CD.",
      "AB = BC.",
      "AC = BD.",
      "Góc A = 90°."
    ],
    "dapAn": "B"
  },
  {
    "id": "TG-V5-04",
    "vung": 5,
    "chuDe": "Điều kiện tổng hợp",
    "dang": "tong-hop",
    "muc": 3,
    "loai": "trac-nghiem",
    "de": "Tứ giác ABCD có hai đường chéo cắt nhau tại trung điểm mỗi đường, bằng nhau và vuông góc. Kết luận nào được bảo đảm bởi toàn bộ các dữ kiện?\n",
    "goiY": "Từ chia đôi nhau suy ra hình bình hành; xét thêm hai điều kiện đường chéo.",
    "loiGiai": [
      "Chia đôi nhau cho hình bình hành; bằng nhau cho hình chữ nhật; vuông góc cho hình thoi. Hình chữ nhật có hai cạnh kề bằng nhau là hình vuông."
    ],
    "loiSai": "Chỉ sử dụng một phần dữ kiện đường chéo.",
    "dapAnDuyet": "A",
    "phuongAn": [
      "ABCD là hình vuông.",
      "ABCD có hai cạnh đối không song song.",
      "ABCD có một góc tù.",
      "ABCD có hai cạnh kề không bằng nhau."
    ],
    "dapAn": "A"
  },
  {
    "id": "TG-V5-05",
    "vung": 5,
    "chuDe": "Tính chất hình thoi",
    "dang": "hinh-thoi",
    "muc": 1,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Tách tính chất hình thoi khỏi tính chất riêng của hình vuông.",
    "loiGiai": [
      "a, b, d là tính chất hình thoi. c không đúng với mọi hình thoi; hai đường chéo có thể khác độ dài."
    ],
    "loiSai": "Gán tính chất đường chéo bằng nhau cho mọi hình thoi.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "Hình thoi là hình bình hành.",
        "dung": true
      },
      {
        "nd": "Hai đường chéo hình thoi vuông góc.",
        "dung": true
      },
      {
        "nd": "Hai đường chéo hình thoi luôn bằng nhau.",
        "dung": false
      },
      {
        "nd": "Mỗi đường chéo hình thoi là phân giác của các góc tại hai đầu mút.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V5-06",
    "vung": 5,
    "chuDe": "Dấu hiệu hình vuông",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Ở c, dữ kiện mới chỉ nhận biết được hình chữ nhật.",
    "loiGiai": [
      "a, b, d là các dấu hiệu hình vuông. c sai vì hình chữ nhật có hai cạnh kề khác nhau vẫn có hai đường chéo bằng nhau."
    ],
    "loiSai": "Quên điều kiện cạnh bằng nhau hoặc đường chéo vuông góc.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "Hình thoi có một góc vuông là hình vuông.",
        "dung": true
      },
      {
        "nd": "Hình chữ nhật có hai đường chéo vuông góc là hình vuông.",
        "dung": true
      },
      {
        "nd": "Hình bình hành có hai đường chéo bằng nhau luôn là hình vuông.",
        "dung": false
      },
      {
        "nd": "Hình thoi có hai đường chéo bằng nhau là hình vuông.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V5-07",
    "vung": 5,
    "chuDe": "Ôn tập quan hệ các hình",
    "dang": "tong-hop",
    "muc": 3,
    "loai": "dung-sai",
    "de": "Xác định đúng/sai:",
    "goiY": "Phải xét đầy đủ giả thiết của từng dấu hiệu.",
    "loiGiai": [
      "a, b đúng theo các tính chất hình vuông. c thiếu điều kiện hình bình hành: tứ giác có đường chéo vuông góc nhưng không chia đôi nhau có thể không là hình thoi. d là dấu hiệu hình thang cân."
    ],
    "loiSai": "Bỏ giả thiết hình bình hành khi nhận biết hình thoi.",
    "dapAnDuyet": "a Đ; b Đ; c S; d Đ",
    "y": [
      {
        "nd": "Mọi hình vuông là hình chữ nhật.",
        "dung": true
      },
      {
        "nd": "Mọi hình vuông là hình thoi.",
        "dung": true
      },
      {
        "nd": "Tứ giác có hai đường chéo vuông góc luôn là hình thoi.",
        "dung": false
      },
      {
        "nd": "Hình thang có hai đường chéo bằng nhau là hình thang cân.",
        "dung": true
      }
    ]
  },
  {
    "id": "TG-V5-08",
    "vung": 5,
    "chuDe": "Góc của hình thoi",
    "dang": "hinh-thoi",
    "muc": 1,
    "loai": "dien",
    "de": "Hình thoi ABCD có góc A = 68°. Tính góc B, đơn vị độ.",
    "goiY": "Hai góc kề một cạnh của hình bình hành bù nhau.",
    "loiGiai": [
      "Hình thoi là hình bình hành nên B = 180° − 68° = 112°."
    ],
    "loiSai": "Cho hai góc kề bằng nhau.",
    "dapAnDuyet": "112",
    "dapAn": "112",
    "donVi": "°"
  },
  {
    "id": "TG-V5-09",
    "vung": 5,
    "chuDe": "Phân giác trong hình thoi",
    "dang": "hinh-thoi",
    "muc": 2,
    "loai": "dien",
    "de": "Hình thoi ABCD có góc DAB = 116°. Tính góc BAC, đơn vị độ.",
    "goiY": "AC là phân giác góc DAB.",
    "loiGiai": [
      "Góc BAC = 116°/2 = 58° theo tính chất đường chéo hình thoi."
    ],
    "loiSai": "Dùng góc bù thay vì nửa góc tại A.",
    "dapAnDuyet": "58",
    "dapAn": "58",
    "donVi": "°"
  },
  {
    "id": "TG-V5-10",
    "vung": 5,
    "chuDe": "Độ dài cạnh hình vuông",
    "dang": "hinh-vuong",
    "muc": 1,
    "loai": "dien",
    "de": "Tổng độ dài bốn cạnh một hình vuông bằng 34 cm. Tính độ dài một cạnh, đơn vị cm.",
    "goiY": "Bốn cạnh có cùng độ dài.",
    "loiGiai": [
      "Mỗi cạnh dài 34 : 4 = 8,5 cm."
    ],
    "loiSai": "Chia tổng cho 2.",
    "dapAnDuyet": "8,5",
    "dapAn": "8,5",
    "donVi": "cm"
  },
  {
    "id": "TG-V5-11",
    "vung": 5,
    "chuDe": "Hai nửa đường chéo",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "dien",
    "de": "Hình vuông ABCD có hai đường chéo cắt nhau tại O; OA = 3x − 1 cm và OB = x + 5 cm. Tìm x.",
    "goiY": "Hai đường chéo bằng nhau và chia đôi nhau.",
    "loiGiai": [
      "OA = OB nên 3x − 1 = x + 5, suy ra x = 3. OA = OB = 8 cm."
    ],
    "loiSai": "Chỉ biết chia đôi từng đường mà không dùng hai đường chéo bằng nhau.",
    "dapAnDuyet": "3",
    "dapAn": "3",
    "donVi": ""
  },
  {
    "id": "TG-V5-12",
    "vung": 5,
    "chuDe": "So sánh các góc",
    "dang": "hinh-thoi",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Hình thoi ABCD có góc A = 120°. Xếp các thẻ góc B; góc BAC; góc ABD theo số đo tăng dần. Nếu hai thẻ bằng nhau, có thể đặt chúng theo một trong hai thứ tự.",
    "goiY": "Tính góc B; mỗi đường chéo chia đôi góc tại đầu mút.",
    "loiGiai": [
      "B = 60°; BAC = 60°; ABD = 30°. Hai góc B và BAC bằng nhau nên chấp nhận cả hai thứ tự đã nêu."
    ],
    "loiSai": "Coi hai số đo bằng nhau chỉ có một cách sắp xếp hợp lệ.",
    "dapAnDuyet": "ABD → B → BAC hoặc ABD → BAC → B",
    "nhan": [
      "Góc B",
      "Góc BAC",
      "Góc ABD"
    ],
    "so": [
      "60",
      "60",
      "30"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V5-13",
    "vung": 5,
    "chuDe": "So sánh nửa đường chéo",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "sap-xep",
    "de": "Ba hình vuông I, II, III có đường chéo lần lượt dài 14 cm, 10 cm, 18 cm. Xếp khoảng cách từ giao điểm đường chéo đến một đỉnh của mỗi hình theo thứ tự tăng dần.",
    "goiY": "Khoảng cách cần tìm bằng nửa đường chéo tương ứng.",
    "loiGiai": [
      "Ba khoảng cách lần lượt là 7 cm, 5 cm, 9 cm. Tăng dần: II, I, III."
    ],
    "loiSai": "So sánh sai thứ tự hoặc chia đôi không nhất quán.",
    "dapAnDuyet": "Hình II → hình I → hình III",
    "nhan": [
      "Hình I",
      "Hình II",
      "Hình III"
    ],
    "so": [
      "7",
      "5",
      "9"
    ],
    "chieu": "tang"
  },
  {
    "id": "TG-V5-14",
    "vung": 5,
    "chuDe": "Nhận diện đường chéo vuông góc",
    "dang": "hinh-vuong",
    "muc": 1,
    "loai": "chon-hinh",
    "de": "Hình F5 là hình thoi ABCD. Chọn đường chéo vuông góc AC. Các đối tượng chọn: AB, BC, CD, DA, BD.",
    "goiY": "Xác định đường chéo còn lại của hình thoi.",
    "loiGiai": [
      "Hai đường chéo AC và BD vuông góc nên chọn BD. Không dựa vào góc nhìn của hình."
    ],
    "loiSai": "Chọn một cạnh trông có vẻ vuông góc với AC.",
    "dapAnDuyet": "BD",
    "hinh": "F5",
    "doiTuong": [
      "AB",
      "BC",
      "CD",
      "DA",
      "BD"
    ],
    "dapAn": "BD"
  },
  {
    "id": "TG-V5-15",
    "vung": 5,
    "chuDe": "Nhận diện phân giác",
    "dang": "hinh-thoi",
    "muc": 2,
    "loai": "chon-hinh",
    "de": "Hình F5 là hình thoi ABCD. Chọn đường chéo chia đôi góc DAB. Các đối tượng chọn: AB, AD, AC, BD, BC.",
    "goiY": "Đường chéo phân giác góc tại đầu mút của chính nó.",
    "loiGiai": [
      "AC đi qua đỉnh A và là phân giác góc DAB theo tính chất hình thoi."
    ],
    "loiSai": "Chọn BD chỉ vì hai đường chéo vuông góc.",
    "dapAnDuyet": "AC",
    "hinh": "F5",
    "doiTuong": [
      "AB",
      "AD",
      "AC",
      "BD",
      "BC"
    ],
    "dapAn": "AC"
  },
  {
    "id": "TG-V5-16",
    "vung": 5,
    "chuDe": "Ghép dấu hiệu hình vuông",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "ghep",
    "de": "Ghép mỗi giả thiết với điều kiện bổ sung đủ để nhận biết hình vuông; mỗi nhãn dùng một lần.",
    "goiY": "Kiểm tra tên các đỉnh và điều kiện còn thiếu của từng hình.",
    "loiGiai": [
      "1: hình chữ nhật có hai cạnh kề bằng nhau. 2: hình thoi có hai đường chéo bằng nhau. 3: hình bình hành có hai cạnh kề bằng nhau là hình thoi; thêm góc vuông thành hình vuông."
    ],
    "loiSai": "Áp dụng điều kiện mà không xét loại hình đã biết.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "Hình chữ nhật ABCD",
        "phai": "AB = BC"
      },
      {
        "trai": "Hình thoi EFGH",
        "phai": "EG = FH"
      },
      {
        "trai": "Hình bình hành MNPQ có MN = NP",
        "phai": "Góc M = 90°"
      }
    ]
  },
  {
    "id": "TG-V5-17",
    "vung": 5,
    "chuDe": "Ghép góc hình thoi",
    "dang": "hinh-thoi",
    "muc": 2,
    "loai": "ghep",
    "de": "Mỗi trường hợp là hình thoi ABCD. Ghép với số đo góc BAC.",
    "goiY": "AC chia đôi góc A; ở trường hợp 2 cần tính A trước.",
    "loiGiai": [
      "Lần lượt BAC = 40°; BAC = (180° − 70°)/2 = 55°; BAC = 60°."
    ],
    "loiSai": "Chia đôi góc B khi đề hỏi góc BAC.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "Góc A = 80°",
        "phai": "40°"
      },
      {
        "trai": "Góc B = 70°",
        "phai": "55°"
      },
      {
        "trai": "Góc A = 120°",
        "phai": "60°"
      }
    ]
  },
  {
    "id": "TG-V5-18",
    "vung": 5,
    "chuDe": "Ghép căn cứ toàn chương",
    "dang": "tong-hop",
    "muc": 3,
    "loai": "ghep",
    "de": "Ghép dữ kiện với kết luận trực tiếp tương ứng; mỗi nhãn dùng một lần.",
    "goiY": "Cùng một điều kiện đường chéo nhưng giả thiết ban đầu khác nhau.",
    "loiGiai": [
      "1 dùng dấu hiệu hình thang cân; 2 dùng dấu hiệu hình chữ nhật; 3 dùng dấu hiệu hai cạnh kề bằng nhau của hình bình hành."
    ],
    "loiSai": "Chỉ đọc điều kiện bổ sung, bỏ qua loại hình ban đầu.",
    "dapAnDuyet": "1-b; 2-c; 3-a",
    "cap": [
      {
        "trai": "Hình thang ABCD có AC = BD",
        "phai": "ABCD là hình thang cân"
      },
      {
        "trai": "Hình bình hành EFGH có EG = FH",
        "phai": "EFGH là hình chữ nhật"
      },
      {
        "trai": "Hình bình hành MNPQ có MN = NP",
        "phai": "MNPQ là hình thoi"
      }
    ]
  },
  {
    "id": "TG-V5-19",
    "vung": 5,
    "chuDe": "Lỗi nhận biết hình thoi",
    "dang": "hinh-thoi",
    "muc": 3,
    "loai": "bat-loi",
    "de": "Cho tứ giác ABCD có AC vuông góc BD. Tìm bước sai đầu tiên.",
    "goiY": "Dấu hiệu theo đường chéo vuông góc cần giả thiết gì?",
    "loiGiai": [
      "Chưa biết ABCD là hình bình hành nên không được áp dụng dấu hiệu hình thoi. Bước 2 là sai đầu tiên; các cạnh kề chưa chắc bằng nhau."
    ],
    "loiSai": "Thiếu giả thiết hình bình hành.",
    "dapAnDuyet": "Bước 2",
    "vanBan": true,
    "buoc": [
      "Hai đường chéo vuông góc.",
      "Suy ra ABCD là hình thoi.",
      "Suy ra AB = BC."
    ],
    "buocSai": 2,
    "dau": ""
  },
  {
    "id": "TG-V5-20",
    "vung": 5,
    "chuDe": "Lỗi tính góc trong hình vuông",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "bat-loi",
    "de": "Cho hình vuông ABCD. Tìm bước sai đầu tiên.",
    "goiY": "Phân giác chia một góc thành hai góc bằng nhau.",
    "loiGiai": [
      "Hai bước đầu đúng vì hình vuông vừa là hình chữ nhật vừa là hình thoi. BAC = 90°/2 = 45°, nên bước 3 sai."
    ],
    "loiSai": "Giữ nguyên số đo góc khi đã lấy phân giác.",
    "dapAnDuyet": "Bước 3",
    "vanBan": true,
    "buoc": [
      "Góc DAB = 90°.",
      "AC là phân giác góc DAB.",
      "Góc BAC = 90°."
    ],
    "buocSai": 3,
    "dau": ""
  },
  {
    "id": "TG-V5-21",
    "vung": 5,
    "chuDe": "Chứng minh hình vuông từ cạnh",
    "dang": "hinh-vuong",
    "muc": 2,
    "loai": "thu-tu-buoc",
    "de": "Cho ABCD là hình bình hành có AB = BC và góc A = 90°. Sắp xếp các thẻ dưới đây.",
    "goiY": "P và Q đều suy ra trực tiếp từ giả thiết.",
    "loiGiai": [
      "Hai bước P, Q độc lập; R dùng đồng thời kết quả của cả hai. Chấp nhận cả hai thứ tự."
    ],
    "loiSai": "Cho rằng P phải luôn đứng trước Q dù không có quan hệ phụ thuộc.",
    "dapAnDuyet": "P → Q → R hoặc Q → P → R",
    "buoc": [
      "P: ABCD là hình thoi vì hình bình hành có hai cạnh kề bằng nhau.",
      "Q: ABCD là hình chữ nhật vì hình bình hành có một góc vuông.",
      "R: Từ hai kết quả trên, ABCD vừa có bốn cạnh bằng nhau vừa có bốn góc vuông nên là hình vuông."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        2
      ]
    ]
  },
  {
    "id": "TG-V5-22",
    "vung": 5,
    "chuDe": "Chứng minh tổng hợp đường chéo",
    "dang": "tong-hop",
    "muc": 3,
    "loai": "thu-tu-buoc",
    "de": "Tứ giác ABCD có hai đường chéo chia đôi nhau, bằng nhau và vuông góc. Sắp xếp các thẻ dưới đây.",
    "goiY": "P là bước mở đầu; Q và R độc lập sau P; S dùng cả Q lẫn R.",
    "loiGiai": [
      "Trật tự phụ thuộc là P trước Q, R; cả Q, R trước S. Vì vậy có đúng hai thứ tự hợp lệ được liệt kê."
    ],
    "loiSai": "Dùng dấu hiệu hình chữ nhật hoặc hình thoi trước khi chứng minh hình bình hành.",
    "dapAnDuyet": "P → Q → R → S hoặc P → R → Q → S",
    "buoc": [
      "P: ABCD là hình bình hành vì hai đường chéo chia đôi nhau.",
      "Q: Từ kết quả P và AC = BD, suy ra ABCD là hình chữ nhật.",
      "R: Từ kết quả P và AC vuông góc BD, suy ra ABCD là hình thoi.",
      "S: Từ Q và R, ABCD có bốn góc vuông và bốn cạnh bằng nhau nên là hình vuông."
    ],
    "thuTuDung": [
      [
        0,
        1,
        2,
        3
      ],
      [
        0,
        2,
        1,
        3
      ]
    ]
  }
];
