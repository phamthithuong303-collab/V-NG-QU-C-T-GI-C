// Giữ cơ chế, nhân vật, vật phẩm và số thử thách của bản gốc.
window.COT_TRUYEN = {
  "DANG": [
    {
      "id": "tu-giac",
      "ten": "Khái niệm và yếu tố tứ giác"
    },
    {
      "id": "goc-tu-giac",
      "ten": "Tổng góc tứ giác"
    },
    {
      "id": "thang-can",
      "ten": "Định nghĩa và yếu tố hình thang cân"
    },
    {
      "id": "can-tinh-chat",
      "ten": "Tính chất hình thang cân"
    },
    {
      "id": "can-nhan-biet",
      "ten": "Nhận biết hình thang cân"
    },
    {
      "id": "binh-hanh",
      "ten": "Định nghĩa và tính chất hình bình hành"
    },
    {
      "id": "hbh-nhan-biet",
      "ten": "Nhận biết hình bình hành"
    },
    {
      "id": "hbh-cheo",
      "ten": "Đường chéo hình bình hành"
    },
    {
      "id": "chu-nhat",
      "ten": "Định nghĩa và nhận biết hình chữ nhật"
    },
    {
      "id": "hcn-cheo",
      "ten": "Đường chéo hình chữ nhật"
    },
    {
      "id": "trung-tuyen",
      "ten": "Trung tuyến ứng với cạnh huyền"
    },
    {
      "id": "hinh-thoi",
      "ten": "Tính chất và nhận biết hình thoi"
    },
    {
      "id": "hinh-vuong",
      "ten": "Tính chất và nhận biết hình vuông"
    },
    {
      "id": "tong-hop",
      "ten": "Lập luận và ôn tập toàn chương"
    }
  ],
  "LOAI": {
    "trac-nghiem": "Trắc nghiệm",
    "dung-sai": "Đúng / Sai",
    "dien": "Điền đáp số",
    "sap-xep": "Sắp xếp số đo",
    "chon-hinh": "Chọn trên hình",
    "ghep": "Ghép đôi",
    "bat-loi": "Bắt lỗi sai",
    "thu-tu-buoc": "Sắp xếp chứng minh"
  },
  "MUC": {
    "1": "Dễ",
    "2": "Thường",
    "3": "Khó"
  },
  "LOP_NHAN_VAT": {
    "chien-binh": {
      "ten": "Chiến binh",
      "icon": "⚔️",
      "tim": 7,
      "kiNang": "Giáp dày: có 7 tim thay vì 5."
    },
    "phap-su": {
      "ten": "Pháp sư",
      "icon": "🔮",
      "tim": 5,
      "kiNang": "Thần chú: 2 lần gợi ý miễn phí mỗi thử thách."
    },
    "tham-hiem": {
      "ten": "Thám hiểm",
      "icon": "🧭",
      "tim": 5,
      "kiNang": "Ống nhòm: mỗi thử thách được loại bỏ 1 đáp án sai."
    },
    "tho-ren": {
      "ten": "Thợ rèn",
      "icon": "🔨",
      "tim": 5,
      "kiNang": "Khiên rèn: lần sai đầu tiên mỗi thử thách không mất tim."
    }
  },
  "AVATAR": [
    "🦊",
    "🐯",
    "🐼",
    "🐸",
    "🦁",
    "🐨",
    "🐧",
    "🦄",
    "🐲",
    "🐱",
    "🐶",
    "🐵"
  ],
  "CUA_HANG": [
    {
      "id": "goiY",
      "ten": "Cuộn gợi ý",
      "icon": "📜",
      "gia": 15,
      "moTa": "Hiện bước đầu của lời giải."
    },
    {
      "id": "nam",
      "ten": "Phép 50:50",
      "icon": "✂️",
      "gia": 25,
      "moTa": "Xoá 2 phương án sai (câu trắc nghiệm 4 phương án)."
    },
    {
      "id": "boQua",
      "ten": "Giày bỏ qua",
      "icon": "👟",
      "gia": 35,
      "moTa": "Bỏ qua 1 câu, không mất tim."
    },
    {
      "id": "binhMau",
      "ten": "Bình máu",
      "icon": "🧪",
      "gia": 20,
      "moTa": "Hồi 1 tim trong lúc làm thử thách."
    }
  ],
  "HUY_HIEU": [
    {
      "id": "buoc-dau",
      "icon": "🌱",
      "ten": "Bước chân đầu tiên",
      "moTa": "Hoàn thành thử thách đầu tiên."
    },
    {
      "id": "combo-5",
      "icon": "🔥",
      "ten": "Combo 5",
      "moTa": "Đúng 5 câu liên tiếp."
    },
    {
      "id": "combo-10",
      "icon": "⚡",
      "ten": "Combo 10",
      "moTa": "Đúng 10 câu liên tiếp."
    },
    {
      "id": "combo-20",
      "icon": "🌟",
      "ten": "Combo 20",
      "moTa": "Đúng 20 câu liên tiếp."
    },
    {
      "id": "hoan-hao",
      "icon": "💎",
      "ten": "Hoàn hảo",
      "moTa": "Qua một thử thách mức Thường hoặc Khó mà không sai câu nào."
    },
    {
      "id": "dung-gia-thiet",
      "icon": "➖",
      "ten": "Đủ giả thiết",
      "moTa": "Đúng liên tiếp 10 câu thuộc nhóm nhận biết hình thang cân, hình bình hành, hình chữ nhật, hình thoi."
    },
    {
      "id": "tinh-goc",
      "icon": "🏃",
      "ten": "Tính góc thần tốc",
      "moTa": "Đúng 10 câu về tổng góc tứ giác."
    },
    {
      "id": "duong-cheo",
      "icon": "🗼",
      "ten": "Bậc thầy đường chéo",
      "moTa": "Đúng 15 câu về đường chéo hình bình hành, hình chữ nhật."
    },
    {
      "id": "tho-san-loi",
      "icon": "🔍",
      "ten": "Thợ săn lỗi sai",
      "moTa": "Bắt đúng 5 lỗi sai trong lời giải."
    },
    {
      "id": "than-toc",
      "icon": "⏱️",
      "ten": "Thần tốc",
      "moTa": "Đúng từ 10 câu trở lên trong một lượt Đấu trí."
    },
    {
      "id": "diet-boss",
      "icon": "🗡️",
      "ten": "Diệt mini-boss",
      "moTa": "Đánh bại mini-boss đầu tiên."
    },
    {
      "id": "ba-sao",
      "icon": "⭐",
      "ten": "Ba sao toàn vùng",
      "moTa": "Đạt 3 sao ở mọi thử thách của một vùng."
    },
    {
      "id": "dung-cam",
      "icon": "🏔️",
      "ten": "Dũng cảm",
      "moTa": "Hoàn thành 5 thử thách ở mức Khó."
    },
    {
      "id": "khong-bo-cuoc",
      "icon": "🔄",
      "ten": "Không bỏ cuộc",
      "moTa": "Hồi sinh rồi vượt qua chính thử thách đó."
    },
    {
      "id": "cham-on",
      "icon": "📚",
      "ten": "Chăm ôn tập",
      "moTa": "Giải đúng 10 câu trong Hang Ôn Tập."
    },
    {
      "id": "nha-giau",
      "icon": "💰",
      "ten": "Nhà giàu",
      "moTa": "Có 300 vàng cùng lúc."
    },
    {
      "id": "cuu-vuong-quoc",
      "icon": "👑",
      "ten": "Người giải cứu",
      "moTa": "Đánh bại Quỷ Sai Góc, giải phóng Vương quốc Tứ Giác."
    }
  ],
  "MO_DAU": [
    "Vương quốc Tứ Giác từng yên bình, nơi những cạnh và góc tạo nên bao công trình đẹp.",
    "Một đêm, **Quỷ Sai Góc** và **Phù thủy Đường Chéo** kéo đến. Chúng tráo các giả thiết, làm rối những lời giải, rồi phong ấn cả năm vùng đất.",
    "Chỉ một **Hiệp sĩ Toán học** mới phá được phong ấn. Người đó chính là em!"
  ],
  "VUNG": [
    {
      "id": 1,
      "ten": "Làng Tứ Giác",
      "icon": "🏡",
      "mau": "#58b947",
      "bai": "Bài 10. Tứ giác",
      "npc": {
        "ten": "Cụ Cú Mèo",
        "icon": "🦉"
      },
      "chao": "Hú hú! Sói Lạc Góc đã xáo trộn cạnh và góc của làng. Cháu giúp ta sắp xếp lại nhé!",
      "thuThach": [
        {
          "ten": "Cổng làng",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "trac-nghiem",
            "dung-sai",
            "ghep",
            "dien"
          ],
          "loi": "Muốn vào làng, hãy nhận đúng các yếu tố của tứ giác!"
        },
        {
          "ten": "Giếng Góc Đối",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "ghep",
            "dien",
            "trac-nghiem",
            "bat-loi"
          ],
          "loi": "Soi xuống giếng, tìm các đỉnh đối và những góc của tứ giác nhé!"
        },
        {
          "ten": "Đấu trí ở Chợ Phiên",
          "loai": "dau-tri",
          "thoiGian": 60,
          "loi": "Chợ sắp đóng cửa! Trả lời thật nhanh trong 60 giây."
        },
        {
          "ten": "Cầu Đường Chéo",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "chon-hinh",
            "sap-xep",
            "trac-nghiem",
            "dung-sai"
          ],
          "loi": "Mỗi tấm ván cầu là một đoạn trên hình. Chọn đúng để qua cầu nhé!"
        },
        {
          "ten": "Tháp Canh Tổng Góc",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "sap-xep",
            "dung-sai",
            "thu-tu-buoc",
            "dien",
            "bat-loi"
          ],
          "loi": "Lên tháp canh, tính đủ bốn góc rồi sắp xếp nào!"
        },
        {
          "ten": "Hang Sói",
          "loai": "boss",
          "boss": {
            "ten": "Sói Lạc Góc",
            "icon": "🐺",
            "mau": [
              4,
              5,
              6
            ],
            "mo": "Gừ… Tổng bốn góc là 180 độ! Ngươi có tìm được lỗi không?",
            "trung": [
              "Á! Ngươi dùng đúng giả thiết!",
              "Đau quá! Lời giải chặt chẽ quá!",
              "Gừ… lại đúng nữa!"
            ],
            "danh": [
              "Ha ha, sai rồi!",
              "Ngươi nhầm tính chất rồi nhé!",
              "Kiểm tra lại giả thiết đi nào!"
            ],
            "thua": "Ta chịu thua! Nhưng vùng đất tiếp theo vẫn còn bị phong ấn!"
          }
        }
      ]
    },
    {
      "id": 2,
      "ten": "Thành Hình Thang Cân",
      "icon": "🏰",
      "mau": "#3d8bd9",
      "bai": "Bài 11. Hình thang cân",
      "npc": {
        "ten": "Bác Rùa Thợ Rèn",
        "icon": "🐢"
      },
      "chao": "Chậm mà chắc nhé cháu! Bóng Ma Góc Đáy dạy cả thành dùng dấu hiệu thiếu giả thiết. Sai bét!",
      "thuThach": [
        {
          "ten": "Cổng thành",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "trac-nghiem",
            "dien",
            "dung-sai",
            "ghep"
          ],
          "loi": "Nhận đúng hai đáy và hai cạnh bên nhé!"
        },
        {
          "ten": "Lò rèn Góc Đáy",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "ghep",
            "trac-nghiem",
            "dien",
            "bat-loi"
          ],
          "loi": "Hai góc kề cùng một đáy của hình thang cân bằng nhau. Búa xuống!"
        },
        {
          "ten": "Đấu trí ở Quảng trường",
          "loai": "dau-tri",
          "thoiGian": 60,
          "loi": "Cả thành đang cổ vũ! Tính góc nhanh nào!"
        },
        {
          "ten": "Chợ Thành",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "dien",
            "thu-tu-buoc",
            "trac-nghiem",
            "dung-sai"
          ],
          "loi": "Người bán, người mua cần tìm đúng cạnh và góc. Giúp họ nhé!"
        },
        {
          "ten": "Thư viện Dấu Hiệu",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "bat-loi",
            "dien",
            "ghep",
            "trac-nghiem",
            "dung-sai"
          ],
          "loi": "Tính chất và dấu hiệu nhận biết khác nhau. Đừng dùng thiếu giả thiết!"
        },
        {
          "ten": "Tháp Đường Chéo",
          "loai": "boss",
          "boss": {
            "ten": "Bóng Ma Góc Đáy",
            "icon": "👻",
            "mau": [
              4,
              5,
              6
            ],
            "mo": "Hú hù… Có hai đường chéo bằng nhau là hình thang cân ngay! Đúng không nào?",
            "trung": [
              "Á! Ngươi dùng đúng giả thiết!",
              "Đau quá! Lời giải chặt chẽ quá!",
              "Gừ… lại đúng nữa!"
            ],
            "danh": [
              "Ha ha, sai rồi!",
              "Ngươi nhầm tính chất rồi nhé!",
              "Kiểm tra lại giả thiết đi nào!"
            ],
            "thua": "Ta chịu thua! Nhưng vùng đất tiếp theo vẫn còn bị phong ấn!"
          }
        }
      ]
    },
    {
      "id": 3,
      "ten": "Rừng Bình Hành",
      "icon": "🌲",
      "mau": "#2f9e77",
      "bai": "Bài 12. Hình bình hành",
      "npc": {
        "ten": "Tiên Nấm",
        "icon": "🍄"
      },
      "chao": "Các cây tạo nên những khung hình bình hành. Nhưng Rồng Chéo Lệch làm các lời giải rối tung cả!",
      "thuThach": [
        {
          "ten": "Bìa rừng",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "trac-nghiem",
            "dung-sai",
            "dien",
            "ghep"
          ],
          "loi": "Hai cặp cạnh đối song song tạo nên hình bình hành. Nhớ nhé!"
        },
        {
          "ten": "Suối Cạnh Đối",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "ghep",
            "trac-nghiem",
            "bat-loi",
            "dien"
          ],
          "loi": "Các cạnh đối bằng nhau, các góc đối bằng nhau. Suối chảy êm thôi!"
        },
        {
          "ten": "Đấu trí dưới Cây Cổ Thụ",
          "loai": "dau-tri",
          "thoiGian": 60,
          "loi": "Lá rơi rồi! Tính góc trước khi lá chạm đất!"
        },
        {
          "ten": "Hang Hai Đường Chéo",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "thu-tu-buoc",
            "sap-xep",
            "dien",
            "trac-nghiem"
          ],
          "loi": "Hai đường chéo chia đôi nhau. Đừng nhầm thành bằng nhau!"
        },
        {
          "ten": "Đồi Song Song",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "dien",
            "bat-loi",
            "dung-sai",
            "ghep",
            "trac-nghiem"
          ],
          "loi": "Dùng đúng dấu hiệu để nhận biết những khung hình bình hành!"
        },
        {
          "ten": "Tổ Rồng",
          "loai": "boss",
          "boss": {
            "ten": "Rồng Chéo Lệch",
            "icon": "🐲",
            "mau": [
              4,
              5,
              6
            ],
            "mo": "Gào! Hai đường chéo hình bình hành luôn bằng nhau! Ngươi dám cãi không?",
            "trung": [
              "Á! Ngươi dùng đúng giả thiết!",
              "Đau quá! Lời giải chặt chẽ quá!",
              "Gừ… lại đúng nữa!"
            ],
            "danh": [
              "Ha ha, sai rồi!",
              "Ngươi nhầm tính chất rồi nhé!",
              "Kiểm tra lại giả thiết đi nào!"
            ],
            "thua": "Ta chịu thua! Nhưng vùng đất tiếp theo vẫn còn bị phong ấn!"
          }
        }
      ]
    },
    {
      "id": 4,
      "ten": "Núi Hình Chữ Nhật",
      "icon": "⛰️",
      "mau": "#c77d2e",
      "bai": "Bài 13. Hình chữ nhật",
      "npc": {
        "ten": "Đại Bàng Núi",
        "icon": "🦅"
      },
      "chao": "Leo núi phải chắc từng bước suy luận. Khổng Lồ Góc Vuông đang chặn đường lên đỉnh!",
      "thuThach": [
        {
          "ten": "Chân núi",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "trac-nghiem",
            "thu-tu-buoc",
            "dien",
            "ghep"
          ],
          "loi": "Bốn góc vuông làm nên hình chữ nhật. Bước đầu tiên đây!"
        },
        {
          "ten": "Dốc Góc Vuông",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "dung-sai",
            "bat-loi",
            "trac-nghiem",
            "dien"
          ],
          "loi": "Hình bình hành có một góc vuông là hình chữ nhật. Đừng quên giả thiết!"
        },
        {
          "ten": "Đấu trí trên Vách Đá",
          "loai": "dau-tri",
          "thoiGian": 60,
          "loi": "Gió lớn quá! Giải nhanh để bám vào vách đá!"
        },
        {
          "ten": "Cầu Trung Tuyến",
          "loai": "thu-thach",
          "soCau": 4,
          "uuTien": [
            "dien",
            "thu-tu-buoc",
            "bat-loi",
            "trac-nghiem"
          ],
          "loi": "Trong tam giác vuông, trung tuyến ứng với cạnh huyền bằng nửa cạnh ấy!"
        },
        {
          "ten": "Làng Trên Mây",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "dien",
            "sap-xep",
            "ghep",
            "dung-sai",
            "trac-nghiem"
          ],
          "loi": "Dân làng cần đo cạnh và đường chéo. Giúp họ với!"
        },
        {
          "ten": "Đỉnh núi",
          "loai": "boss",
          "boss": {
            "ten": "Khổng Lồ Góc Vuông",
            "icon": "🗿",
            "mau": [
              4,
              5,
              6
            ],
            "mo": "Ta có hai đường chéo bằng nhau nên chắc chắn là hình chữ nhật! Ai cản được ta?",
            "trung": [
              "Á! Ngươi dùng đúng giả thiết!",
              "Đau quá! Lời giải chặt chẽ quá!",
              "Gừ… lại đúng nữa!"
            ],
            "danh": [
              "Ha ha, sai rồi!",
              "Ngươi nhầm tính chất rồi nhé!",
              "Kiểm tra lại giả thiết đi nào!"
            ],
            "thua": "Ta chịu thua! Nhưng vùng đất tiếp theo vẫn còn bị phong ấn!"
          }
        }
      ]
    },
    {
      "id": 5,
      "ten": "Lâu Đài Thoi Vuông",
      "icon": "🏯",
      "mau": "#8a4fd1",
      "bai": "Bài 14. Hình thoi và hình vuông",
      "npc": {
        "ten": "Công chúa Tứ Giác",
        "icon": "👸"
      },
      "chao": "Hiệp sĩ ơi! Hãy vượt qua hình thoi, hình vuông rồi dùng kiến thức cả chương để phá phong ấn!",
      "thuThach": [
        {
          "ten": "Cổng lâu đài",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "trac-nghiem",
            "dien",
            "dung-sai",
            "ghep",
            "sap-xep"
          ],
          "loi": "Cánh cổng chỉ mở khi em nhận đúng hình thoi và hình vuông."
        },
        {
          "ten": "Hành lang Gương",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "bat-loi",
            "chon-hinh",
            "trac-nghiem",
            "dien",
            "thu-tu-buoc"
          ],
          "loi": "Gương phản chiếu lời giải sai về cạnh và góc. Tìm lỗi nhé!"
        },
        {
          "ten": "Đấu trí ở Đại sảnh",
          "loai": "dau-tri",
          "thoiGian": 60,
          "loi": "Lính canh đang tới! Tính góc và cạnh thật nhanh!"
        },
        {
          "ten": "Phòng Kho Báu",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "dien",
            "sap-xep",
            "ghep",
            "thu-tu-buoc",
            "trac-nghiem"
          ],
          "loi": "Kho báu chỉ dành cho người dùng đúng tính chất hình vuông."
        },
        {
          "ten": "Tháp Phù thủy",
          "loai": "thu-thach",
          "soCau": 5,
          "uuTien": [
            "dung-sai",
            "bat-loi",
            "dien",
            "trac-nghiem",
            "ghep"
          ],
          "loi": "Kiểm tra đủ giả thiết trước khi kết luận hình vuông nhé!"
        },
        {
          "ten": "Phòng Ngai Vàng",
          "loai": "boss",
          "boss": {
            "ten": "Phù thủy Đường Chéo",
            "icon": "🧙‍♀️",
            "mau": [
              4,
              5,
              6
            ],
            "mo": "Hô hô! Hai đường chéo vuông góc là hình vuông! Không cần thêm giả thiết!",
            "trung": [
              "Á! Ngươi dùng đúng giả thiết!",
              "Đau quá! Lời giải chặt chẽ quá!",
              "Gừ… lại đúng nữa!"
            ],
            "danh": [
              "Ha ha, sai rồi!",
              "Ngươi nhầm tính chất rồi nhé!",
              "Kiểm tra lại giả thiết đi nào!"
            ],
            "thua": "Ta… ta thua rồi! Quỷ Sai Góc ơi, cứu ta!"
          },
          "boss2": {
            "ten": "Quỷ Sai Góc",
            "icon": "👹",
            "mau": [
              4,
              5,
              6
            ],
            "mo": "Ha ha! Ta trộn mọi kiến thức về tứ giác. Ngươi có đủ bản lĩnh giải hết không?",
            "trung": [
              "Gàooo! Ngươi tính góc đúng!",
              "Đường chéo… lại là đường chéo!",
              "Không! Ngươi nhớ đủ giả thiết!"
            ],
            "danh": [
              "Ha ha, sai góc rồi!",
              "Thiếu giả thiết rồi kìa!",
              "Nhầm tính chất rồi nhé!"
            ],
            "thua": "Khônggg! Phong ấn đã vỡ… Vương quốc Tứ Giác được tự do!"
          }
        }
      ]
    }
  ],
  "KET_THUC": [
    "Phong ấn tan biến. Các cạnh và góc trở về đúng vị trí, những lời giải đã có đủ giả thiết.",
    "Cả vương quốc reo vang tên em: Hiệp sĩ Toán học!"
  ]
};
