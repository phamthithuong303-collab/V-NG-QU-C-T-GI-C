/* 14 mẫu hình học. vung=0: ôn toàn chương; vung=5: thoi/vuông.
   nhanh=true luôn là trắc nghiệm, giữ vai trò Đấu trí. */
(function(root){
'use strict';
const ri=(a,b)=>a+Math.floor(Math.random()*(b-a+1)),pick=a=>a[Math.floor(Math.random()*a.length)];let seq=0;
const MAU={};
function add(id,vung,dang,tao){MAU[id]={vung,dang,tao};}
function data(de,so,goiY,giai,loi,thamSo){return {de,so,goiY,giai,loi,thamSo};}
add('tong-goc',1,'goc-tu-giac',m=>{const a=ri(6,10)*10,b=ri(7,11)*10,c=ri(7,10)*10,d=360-a-b-c;return data(`Tứ giác lồi ABCD có A = ${a}°, B = ${b}°, C = ${c}°. Tính góc D (độ).`,d,'Tổng bốn góc trong tứ giác bằng 360°.',`D = 360° − (${a}° + ${b}° + ${c}°) = ${d}°.`, 'Lấy tổng góc bằng 180°.',{a,b,c,d});});
add('hai-goc-bang',1,'goc-tu-giac',m=>{const a=ri(6,12)*10,b=ri(6,12)*10,d=(360-a-b)/2;return data(`Tứ giác lồi ABCD có A = ${a}°, B = ${b}° và C = D. Tính góc C (độ).`,d,'Tìm tổng C + D rồi chia đôi.',`C = D = (360° − ${a}° − ${b}°)/2 = ${d}°.`, 'Quên chia đôi tổng hai góc.',{a,b,c:d,d});});
add('goc-theo-phan',1,'goc-tu-giac',m=>{const parts=pick([[2,3,4,3],[3,2,3,4],[2,4,3,3]]),k=ri(0,3),d=parts[k]*30;return data(`Các góc A, B, C, D của tứ giác lồi tỉ lệ ${parts.join(' : ')}. Tính góc ${'ABCD'[k]} (độ).`,d,'Tổng 12 phần ứng với 360°.',`Mỗi phần bằng 360°/12 = 30°. Góc cần tìm bằng ${parts[k]} × 30° = ${d}°.`, 'Chia cho số góc thay vì tổng số phần.',{parts,k});});
add('goc-thang-can',2,'can-tinh-chat',m=>{const a=ri(10,14)*10,d=180-a;return data(`Hình thang cân ABCD có AB ∥ CD, A = ${a}°. Tính góc C (độ).`,d,'A bù D; hai góc kề đáy CD bằng nhau.',`D = 180° − ${a}° = ${d}°; C = D = ${d}°.`, 'Cho hai góc đối bằng nhau.',{a,b:a,c:d,d});});
add('canh-thang-can',2,'can-tinh-chat',m=>{const a=ri(3,8*m);return data(`Hình thang cân ABCD có AB ∥ CD và AD = ${a} cm. Tính BC (cm).`,a,'Hai cạnh bên hình thang cân bằng nhau.',`AD và BC là hai cạnh bên nên BC = AD = ${a} cm.`, 'Nhầm cạnh bên với đáy.',{canh:a});});
add('cheo-thang-can',2,'can-tinh-chat',m=>{const a=ri(6,12*m);return data(`Hình thang cân ABCD có AC = ${a} cm. Tính BD (cm).`,a,'Hai đường chéo hình thang cân bằng nhau.',`BD = AC = ${a} cm.`, 'Chia đôi đường chéo khi đề hỏi cả đường.',{cheo:a});});
add('goc-binh-hanh',3,'binh-hanh',m=>{const a=ri(4,14)*10,d=180-a;return data(`Hình bình hành ABCD có A = ${a}°. Tính góc B (độ).`,d,'Hai góc kề một cạnh của hình bình hành bù nhau.',`B = 180° − ${a}° = ${d}°.`, 'Nhầm góc kề với góc đối.',{a,b:d,c:a,d});});
add('canh-binh-hanh',3,'binh-hanh',m=>{const a=ri(3,10*m);return data(`Hình bình hành ABCD có AB = ${a} cm. Tính CD (cm).`,a,'Hai cạnh đối hình bình hành bằng nhau.',`CD = AB = ${a} cm.`, 'Lấy nửa độ dài cạnh đối.',{canh:a});});
add('nua-cheo-binh-hanh',3,'hbh-cheo',m=>{const a=ri(6,14*m);return data(`Hai đường chéo hình bình hành ABCD cắt nhau tại O. AC = ${a} cm. Tính OC (cm).`,a/2,'O là trung điểm AC.',`OC = AC/2 = ${a}/2 = ${a/2} cm.`, 'Nhầm một nửa với cả đường chéo.',{cheo:a});});
add('nua-cheo-chu-nhat',4,'hcn-cheo',m=>{const a=ri(8,16*m);return data(`Hai đường chéo hình chữ nhật ABCD cắt nhau tại O. AC = ${a} cm. Tính OB (cm).`,a/2,'AC = BD và O là trung điểm BD.',`BD = ${a} cm; OB = BD/2 = ${a/2} cm.`, 'Quên liên hệ hai đường chéo bằng nhau.',{cheo:a});});
add('trung-tuyen-vuong',4,'trung-tuyen',m=>{const a=ri(8,18*m);return data(`Tam giác ABC vuông tại A; M là trung điểm BC và BC = ${a} cm. Tính AM (cm).`,a/2,'Trung tuyến ứng với cạnh huyền bằng nửa cạnh huyền.',`AM = BC/2 = ${a}/2 = ${a/2} cm.`, 'Đặt trung tuyến bằng cả cạnh huyền.',{huyen:a});});
add('canh-chu-nhat',4,'chu-nhat',m=>{const a=ri(4,10*m),b=ri(3,8*m),p=2*(a+b);return data(`Hình chữ nhật ABCD có tổng bốn cạnh ${p} cm và AB = ${a} cm. Tính BC (cm).`,b,'Nửa tổng bốn cạnh bằng AB + BC.',`BC = ${p}/2 − ${a} = ${b} cm.`, 'Lấy cả tổng bốn cạnh trừ AB.',{a,b,p});});
add('phan-giac-thoi',5,'hinh-thoi',m=>{const a=ri(4,14)*10;return data(`Hình thoi ABCD có góc DAB = ${a}°. Tính góc BAC (độ).`,a/2,'AC là phân giác góc DAB.',`Góc BAC = ${a}°/2 = ${a/2}°.`, 'Giữ nguyên góc A khi lấy phân giác.',{a});});
add('canh-hinh-vuong',5,'hinh-vuong',m=>{const a=ri(6,20*m)/2,p=4*a;return data(`Tổng bốn cạnh hình vuông ABCD là ${p} cm. Tính AB (cm).`,a,'Bốn cạnh hình vuông bằng nhau.',`AB = ${p}/4 = ${a} cm.`, 'Chia tổng bốn cạnh cho 2.',{canh:a,p});});
function sinh(vung,muc,nhanh,tenMau){
 if(![0,1,2,3,4,5].includes(vung)||![1,2,3].includes(muc))throw Error('Vùng hoặc mức không hợp lệ');
 const keys=Object.keys(MAU).filter(k=>tenMau?k===tenMau:(vung===0||MAU[k].vung===vung));if(!keys.length)throw Error('Không có mẫu tương ứng');
 const ten=pick(keys),mau=MAU[ten],x=mau.tao(muc);
 const q={id:'TG-NN-'+Date.now().toString(36)+'-'+(++seq),vung:mau.vung,dang:mau.dang,muc,sinh:ten,de:x.de,goiY:x.goiY,loiGiai:[x.giai],loiSai:x.loi,thamSo:x.thamSo,giaTriDung:x.so};
 if(nhanh||Math.random()<.5){const vals=[x.so];for(const v of [x.so+10,x.so+1,x.so/2,x.so*2,x.so+5])if(v>0&&!vals.includes(v)&&vals.length<4)vals.push(v);q.loai='trac-nghiem';q.phuongAn=vals.map(v=>String(v).replace('.',','));q.dapAn='A';}
 else{q.loai='dien';q.dapAn=String(x.so).replace('.',',');q.donVi=x.de.includes('(độ)')?'°':'cm';}return q;
}
root.SINH_CAU_HOI={sinh,MAU,danhSach:Object.keys(MAU)};
})(typeof window!=='undefined'?window:globalThis);
