/* Hàng đợi bền vững: POST chỉ gửi; JSONP chỉ đọc biên nhận không chứa dữ liệu học sinh.
   Không đánh dấu thành công từ phản hồi opaque của no-cors. */
(function(root){
 'use strict';
 const PREFIX='tugq-outbox-v2:', ACK='tugq-ack-v2:', memory=new Map(), pending=new Map();
 let busy=false, timer=null, failures=0, sendingStudent='', storageError=false;
 const cfg=()=>root.CAU_HINH||{};
 const configured=()=>/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(cfg().urlKetQua||'');
 function id(){const a=new Uint8Array(16);root.crypto.getRandomValues(a);return Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');}
 const normalizeCode=s=>String(s||'').trim().toUpperCase();
 function validIdentity(name,cl,code){return !!(String(name||'').trim()&&String(name).length<=80&&String(cl||'').trim()&&String(cl).length<=20&&/^[A-Z0-9_-]{1,32}$/.test(normalizeCode(code)));}
 function notify(){root.dispatchEvent(new Event('tugq-send-state'));}
 function entries(){const all=new Map();try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(PREFIX)){try{const p=JSON.parse(localStorage.getItem(k));if(p&&p.eventId&&p.student)all.set(p.eventId,p);}catch(_){}}}}catch(_){storageError=true;}for(const [k,v]of memory)all.set(k,v);return [...all.values()].sort((a,b)=>a.endedAt-b.endedAt||a.eventId.localeCompare(b.eventId));}
 function save(p){memory.set(p.eventId,p);try{localStorage.setItem(PREFIX+p.eventId,JSON.stringify(p));storageError=false;}catch(_){storageError=true;}notify();}
 function drop(p){try{localStorage.removeItem(PREFIX+p.eventId);}catch(_){storageError=true;}memory.delete(p.eventId);}
 function status(code){code=normalizeCode(code);const n=entries().filter(p=>p.student.code===code).length;let ack=null;try{ack=JSON.parse(localStorage.getItem(ACK+code));}catch(_){}
  if(sendingStudent===code)return {text:'Đang gửi',pending:n,storageError};
  if(n)return {text:configured()?'Chưa gửi được – vui lòng thử lại':'Chưa gửi được – vui lòng thử lại',pending:n,storageError,reason:configured()?'Kết quả đang chờ trên thiết bị.':'Giáo viên chưa cấu hình URL Apps Script.'};
  return {text:ack?'Đã lưu kết quả':'Chưa có kết quả cần gửi',pending:0,storageError,at:ack&&ack.at};
 }
 // Callback cố định, chỉ tiếp nhận ID + khóa biên nhận + nonce tương ứng yêu cầu đang chờ.
 root.TGSheetsReceipt=function(r){if(!r||typeof r!=='object')return;const p=pending.get(r.nonce);if(p&&r.eventId===p.eventId&&r.receiptKey===p.receiptKey)p.finish(null,r);};
 function receipt(p){return new Promise((resolve,reject)=>{
  const nonce=id(),script=document.createElement('script');let timeout;
  const finish=(err,data)=>{clearTimeout(timeout);pending.delete(nonce);script.remove();err?reject(err):resolve(data);};
  pending.set(nonce,{eventId:p.eventId,receiptKey:p.receiptKey,finish});
  script.referrerPolicy='no-referrer';script.src=cfg().urlKetQua+'?action=receipt&eventId='+encodeURIComponent(p.eventId)+'&key='+encodeURIComponent(p.receiptKey)+'&nonce='+nonce;
  script.onerror=()=>finish(Error('receipt-network'));
  timeout=setTimeout(()=>finish(Error('receipt-timeout')),15000);document.head.appendChild(script);
 });}
 async function post(p){const ctl=new AbortController(),t=setTimeout(()=>ctl.abort(),20000);try{await fetch(cfg().urlKetQua,{method:'POST',mode:'no-cors',credentials:'omit',redirect:'follow',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(p),signal:ctl.signal});}finally{clearTimeout(t);}}
 const pause=ms=>new Promise(r=>setTimeout(r,ms));
 function later(ms){clearTimeout(timer);timer=setTimeout(flush,ms);}
 async function flush(){
  if(busy||!configured()||root.navigator.onLine===false){notify();return false;}
  busy=true;clearTimeout(timer);let complete=true;
  try{for(const p of entries()){
   sendingStudent=p.student.code;notify();
   try{
    // Lần trước có thể đã ghi thành công nhưng phản hồi bị mất.
    let r=await receipt(p);
    if(!r.ok){if(r.state==='rejected')throw Error('server-rejected');
     try{await post(p);}catch(_){} // POST không phải xác nhận; vẫn hỏi biên nhận.
     for(let i=0;i<3;i++){await pause(1000*(i+1));r=await receipt(p);if(r.ok||r.state==='rejected')break;}
    }
    if(r.ok!==true||r.state!=='saved')throw Error('not-confirmed');
    try{localStorage.setItem(ACK+p.student.code,JSON.stringify({at:r.savedAt,eventId:p.eventId}));}catch(_){storageError=true;}
    drop(p);failures=0;
   }catch(_){failures++;complete=false;break;}
   finally{sendingStudent='';notify();}
  }}finally{busy=false;sendingStudent='';notify();if(entries().length&&configured())later(Math.min(60000,2000*Math.pow(2,Math.min(failures,5))));}
  return complete;
 }
 function snapshot(s,at){const progress=[];for(let v=1;v<=5;v++)for(let i=0;i<6;i++){const x=s.tienDo[v][i];progress.push(x?[x.sao,x.muc]:[0,0]);}
  return {profileId:s.id,xp:s.xp,correct:s.dem.dung,wrong:s.dem.sai,progress,finished:!!s.tienDo[5][5],topics:root.COT_TRUYEN.DANG.map(d=>(s.tk[d.id]||[0,0]).slice()),savedAt:at};
 }
 function enqueue(s,detail,eventId,at){if(!validIdentity(s.ten,s.lop,s.maHS))return false;const p={schema:2,eventId:eventId||id(),receiptKey:id()+id(),kind:detail?'attempt':'summary',student:{code:normalizeCode(s.maHS),name:s.ten.trim(),className:s.lop.trim()},endedAt:at||Date.now(),detail:detail||null,summary:null};p.summary=snapshot(s,p.endedAt);save(p);later(0);return p.eventId;}
 function start(b){b.doLuong={id:id(),start:performance.now(),correct:0,wrong:0,hints:0,shown:0,skipped:0,done:false};}
 function shown(b){if(b&&b.doLuong&&!b.doLuong.done)b.doLuong.shown++;}
 function answer(b,correct){if(b&&b.doLuong&&!b.doLuong.done)b.doLuong[correct?'correct':'wrong']++;}
 function hint(b){if(b&&b.doLuong&&!b.doLuong.done)b.doLuong.hints++;}
 function skip(b){if(b&&b.doLuong&&!b.doLuong.done)b.doLuong.skipped++;}
 function finish(s,b,state){if(!b||!b.doLuong||b.doLuong.done)return false;const d=b.doLuong;const at=Date.now();const detail={runId:d.id,region:b.v,stage:b.i+1,mode:b.kieu,difficulty:b.muc,correct:d.correct,wrong:d.wrong,total:b.ds?b.ds.length:d.shown,totalBasis:b.ds?'planned':'shown',shown:d.shown,skipped:d.skipped,xpEarned:b.xpThu,xpTotal:s.xp,elapsedMs:Math.max(0,Math.round(performance.now()-d.start)),hints:d.hints,status:state};const result=enqueue(s,detail,d.id,at);if(result)d.done=true;return result;}
 root.GuiKetQua={configured,normalizeCode,validIdentity,status,flush,enqueue,start,shown,answer,hint,skip,finish,snapshot};
 root.addEventListener('online',()=>later(0));root.addEventListener('storage',e=>{if(e.key&&e.key.startsWith(PREFIX)){notify();later(0);}});later(500);
})(window);
