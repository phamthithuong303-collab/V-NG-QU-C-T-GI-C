/* Hỗ trợ hình học tại đúng vị trí tương tác trục số của bản gốc. */
(function(root){
 'use strict';
 const HINH={
  F1:{A:[70,50],B:[300,30],C:[340,200],D:[105,220]},
  F2:{A:[120,50],B:[280,50],C:[350,190],D:[50,190],H:[120,190]},
  F3:{A:[140,50],B:[350,50],C:[260,190],D:[50,190],O:[200,120]},
  F4:{A:[70,50],B:[330,50],C:[330,190],D:[70,190],O:[200,120]},
  F5:{A:[200,35],B:[350,120],C:[200,205],D:[50,120],O:[200,120]}
 };
 const permutation=(a,n)=>Array.isArray(a)&&a.length===n&&new Set(a).size===n&&a.every(i=>Number.isInteger(i)&&i>=0&&i<n);
 function sapXepDung(q,cur){
  if(!permutation(cur,q.so.length))return false;
  const val=q.so.map(x=>root.PhanSo.valueOf(x));
  return cur.every((k,i)=>!i||(q.chieu==='tang'?val[cur[i-1]].cmp(val[k])<=0:val[cur[i-1]].cmp(val[k])>=0));
 }
 function thuTuDung(q,cur){return permutation(cur,q.buoc.length)&&(q.thuTuDung||[q.buoc.map((_,i)=>i)]).some(order=>order.every((v,i)=>v===cur[i]));}
 function svg(q){
  const pts=HINH[q.hinh];if(!pts)throw Error('Không có hình '+q.hinh);
  const line=(s,attr)=>{const a=pts[s[0]],b=pts[s[1]];if(!a||!b)throw Error('Đoạn không có trên hình: '+s);return `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" ${attr}/>`;};
  let s='<svg viewBox="0 0 400 250" class="hinh-hoc" role="group" aria-label="Hình '+q.hinh+'. Chọn đoạn theo giả thiết của đề.">';
  s+=['AB','BC','CD','DA','AC','BD'].map(k=>line(k,'class="hh-net"')).join('');
  if(pts.H)s+=line('AH','class="hh-net"')+'<path d="M120 178h12v12" class="hh-net"/>';
  s+=q.doiTuong.map(k=>line(k,`class="hh-chon" data-doan="${k}" role="button" tabindex="0" aria-label="Đoạn ${k}" aria-pressed="false"`)).join('');
  for(const [k,p] of Object.entries(pts)){
   const dx=k==='O'?10:(p[0]<200?-14:p[0]>200?14:0),dy=k==='O'?-10:(p[1]<120?-15:20);
   s+=`<text x="${p[0]+dx}" y="${p[1]+dy}" class="hh-nhan">${k}</text>`;
  }
  return s+'</svg>';
 }
 root.HinhHoc={HINH,permutation,sapXepDung,thuTuDung,svg};
})(typeof window!=='undefined'?window:globalThis);
