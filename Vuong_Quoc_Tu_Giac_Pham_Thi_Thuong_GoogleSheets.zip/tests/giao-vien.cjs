// Kiểm thử logic với DOM và dịch vụ Google giả lập; không phải thử trên trình duyệt/Google thật.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');let checks=0,blob,download;const ok=(v,m)=>{assert(v,m);checks++;};
const elements=new Map(),el=()=>({value:'',innerHTML:'',textContent:'',querySelectorAll:()=>[],click(){this.onclick?.();},remove(){}});
const ctx={window:{},TextEncoder,TextDecoder,btoa,atob,Blob,console,
localStorage:{getItem:()=>null,setItem(){}},document:{querySelector:s=>{if(!elements.has(s))elements.set(s,el());return elements.get(s);},querySelectorAll:()=>[],createElement:()=>({click(){download=this.download;},remove(){}}),body:{appendChild(){}}},URL:{createObjectURL:b=>{blob=b;return 'blob:qa';}},navigator:{},setInterval:()=>0,clearInterval(){}};
vm.createContext(ctx);for(const f of ['du-lieu/cot-truyen.js','du-lieu/cau-hinh.js','js/ma-ket-qua.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx);Object.assign(ctx,ctx.window);vm.runInContext(fs.readFileSync(path.join(root,'js/giao-vien.js'),'utf8'),ctx);
const $=s=>ctx.document.querySelector(s);
(async()=>{
$('#mau').click();ok(ctx.MaKetQua.timMa($('#o-ma').value).length===8,'8 mã mẫu');ok($('#ket-qua').innerHTML.includes('hình thoi'),'Nhãn hình học');
$('#csv').click();let csv=await blob.text();ok(download==='xep-hang-tu-giac.csv','Tên CSV');ok(csv.split('\r\n').length===9,'8 học sinh và tiêu đề');ok(csv.split('\r\n')[0].split(',').length===26,'12 cột hồ sơ và 14 cột kiến thức');ok(csv.includes('Bình (mẫu)'),'Unicode');
$('#loc').value='8A1';$('#loc').onchange();$('#csv').click();csv=await blob.text();ok(csv.split('\r\n').length===5&&!csv.includes('8A2'),'Lọc 4 HS lớp 8A1');
const ma=ctx.MaKetQua.timMa($('#o-ma').value)[0];$('#o-ma').value=ma+'\n'+ma;$('#xem').click();ok($('#bao').innerHTML.includes('<b>1</b> học sinh'),'Gộp trùng');
$('#o-ma').value=ma.slice(0,-1)+(ma.endsWith('a')?'b':'a');$('#xem').click();ok($('#bao').innerHTML.includes('1 mã lỗi'),'Báo mã sai');
vm.runInContext(fs.readFileSync(path.join(root,'js/am-thanh.js'),'utf8'),ctx);ok(ctx.window.AmThanh.batTat()===true&&ctx.window.AmThanh.batTat()===false,'Bật tắt âm thanh');
console.log(JSON.stringify({passed:true,assertions:checks,environment:'Node VM; DOM mocked; teacher page retains local codes/CSV only'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
