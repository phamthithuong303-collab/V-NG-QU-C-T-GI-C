/* Kiểm thử Node VM: bộ nhớ, truyền tải và SpreadsheetApp giả lập. Không truy cập Google thật. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');let passed=0;
const ok=(b,m)=>{assert(b,m);passed++;};
class Sheet {
 constructor(name){this.name=name;this.rows=[];this.failNext=false;}
 getLastRow(){return this.rows.length;}
 getRange(row,col,n=1,w=1){const self=this;return {setNumberFormat(f){assert.equal(f,'@');return this;},setValues(v){if(self.failNext){self.failNext=false;throw Error('simulated write failure');}for(let i=0;i<n;i++){self.rows[row-1+i]||=[];for(let j=0;j<w;j++)self.rows[row-1+i][col-1+j]=v[i][j];}return this;},getValues(){return Array.from({length:n},(_,i)=>Array.from({length:w},(_,j)=>self.rows[row-1+i]?.[col-1+j]??''));}};}
 setFrozenRows(){} hideSheet(){this.hidden=true;return this;}
}
const sheets=new Map(),props=new Map();let locked=false,lockDenied=false,flushCount=0;
const db={getId:()=> 'private-test-sheet',getSheetByName:n=>sheets.get(n),insertSheet:n=>{const sh=new Sheet(n);sheets.set(n,sh);return sh;},setSpreadsheetTimeZone:z=>ok(z==='Asia/Ho_Chi_Minh','Múi giờ VN')};
const gas={console,SpreadsheetApp:{getActiveSpreadsheet:()=>db,openById:()=>db,flush(){flushCount++;}},PropertiesService:{getScriptProperties:()=>({setProperty:(k,v)=>props.set(k,v),getProperty:k=>props.get(k)})},LockService:{getScriptLock:()=>({waitLock(){if(locked)throw Error('locked');locked=true;},tryLock(){if(locked||lockDenied)return false;locked=true;return true;},releaseLock(){locked=false;}})},Utilities:{DigestAlgorithm:{SHA_256:'sha256'},Charset:{UTF_8:'utf8'},computeDigest:(_,s)=>[...crypto.createHash('sha256').update(s).digest()],formatDate:(d,tz)=>{assert.equal(tz,'Asia/Ho_Chi_Minh');return new Intl.DateTimeFormat('en-GB',{timeZone:tz,dateStyle:'short',timeStyle:'medium'}).format(d);}},ContentService:{MimeType:{JSON:'json',JAVASCRIPT:'js'},createTextOutput:t=>({text:t,setMimeType(type){this.type=type;return this;}})}};
vm.createContext(gas);vm.runInContext(fs.readFileSync(path.join(root,'cong-cu/google-apps-script.gs'),'utf8'),gas);
const post=p=>JSON.parse(gas.doPost({postData:{contents:JSON.stringify(p)}}).text);
function receipt(p,key=p.receiptKey){const result=gas.doGet({parameter:{action:'receipt',eventId:p.eventId,key,nonce:'f'.repeat(32)}});return JSON.parse(result.text.match(/^window.TGSheetsReceipt\((.*)\);$/)[1]);}
function payload(i=1){return {schema:2,eventId:i.toString(16).padStart(32,'0'),receiptKey:'a'.repeat(64),kind:'attempt',student:{code:'8A1-001',name:'Học sinh mẫu',className:'8A1'},endedAt:Date.now()-10000+i,detail:{runId:i.toString(16).padStart(32,'0'),region:1,stage:1,mode:'thu-thach',difficulty:1,correct:1,wrong:1,total:4,totalBasis:'planned',shown:3,skipped:1,xpEarned:10,xpTotal:10,elapsedMs:12345,hints:1,status:'chua-dat'},summary:{profileId:'profile123',xp:10,correct:1,wrong:1,progress:Array.from({length:30},()=>[0,0]),topics:Array.from({length:14},(_,j)=>j===0?[1,1]:[0,0]),finished:false,savedAt:0}};}
function prepare(p){p.summary.savedAt=p.endedAt;return p;}
async function serverTests(){
 gas.caiDat();ok(sheets.size===3&&sheets.get('_BienNhan').hidden,'Tạo hai bảng và biên nhận ẩn');
 const p=prepare(payload());ok(post(p).ok,'Ghi dữ liệu hợp lệ');ok(receipt(p).ok,'ACK sau ghi');ok(flushCount>=3,'Flush trước/sau biên nhận');
 ok(sheets.get('ChiTietLuotChoi').rows.length===2&&sheets.get('TongHopHocSinh').rows.length===2,'Một dòng chi tiết/tổng hợp');
 const row=sheets.get('ChiTietLuotChoi').rows[1];ok(row[9]==='50'&&row[14]==='2'&&row[8]==='4','Tỉ lệ tính trên câu đã trả lời');ok(row[10]==='10'&&row[11]==='12.345'&&row[12]==='1','XP/thời gian/gợi ý có theo dõi');
 for(let i=0;i<10;i++)post(p);ok(sheets.get('ChiTietLuotChoi').rows.length===2&&sheets.get('_BienNhan').rows.length===2,'Gửi lặp không tạo trùng');
 ok(!receipt(p,'b'.repeat(64)).ok,'Không đọc biên nhận nếu sai khóa');
 ok(!post({...p,receiptKey:'b'.repeat(64)}).ok,'Không ghi đè cùng ID khóa khác');
 ok(!post({...p,detail:{...p.detail,wrong:10}}).ok,'Chặn thống kê bất nhất');
 ok(!post({...p,student:{...p.student,code:'=1+1'}}).ok,'Chặn mã HS sai');
 ok(!post({...p,summary:{...p.summary,correct:999}}).ok,'Chặn tổng chủ đề sai');
 ok(!post({...p,detail:{...p.detail,elapsedMs:-1}}).ok,'Chặn thời gian âm');
 let b=prepare(payload(2));b.student.name='=IMPORTXML("bad")';b.student.className='+SUM(1,2)';ok(post(b).ok,'Nhận chuỗi dưới dạng văn bản');let row2=sheets.get('ChiTietLuotChoi').rows[2];ok(row2[2].startsWith("'=")&&row2[3].startsWith("'+"),'Chống công thức');
 for(const value of ['=1','+1','-1','@X','  =1','\t=1'])ok(gas.text_(value).startsWith("'"),'Chặn tiền tố công thức '+value);
 let newer=prepare(payload(3));newer.summary.xp=newer.detail.xpTotal=50;ok(post(newer).ok,'Cập nhật cùng HS');let older=prepare(payload(4));older.endedAt=p.endedAt-1000;prepare(older);post(older);ok(sheets.get('TongHopHocSinh').rows.length===2&&sheets.get('TongHopHocSinh').rows[1][5]==='50','Dữ liệu chờ cũ không ghi đè tổng hợp mới');
 const repair=prepare(payload(5));sheets.get('TongHopHocSinh').failNext=true;ok(!post(repair).ok&&!receipt(repair).ok,'Không ACK khi mới ghi được chi tiết');const n=sheets.get('ChiTietLuotChoi').rows.length;ok(post(repair).ok&&receipt(repair).ok,'Retry sửa ghi dở');ok(sheets.get('ChiTietLuotChoi').rows.length===n,'Ghi dở không tạo thêm dòng');
 lockDenied=true;const busy=prepare(payload(6));ok(!post(busy).ok&&!receipt(busy).ok,'Lock bận không ghi/ACK');lockDenied=false;ok(post(busy).ok,'Lock rảnh retry được');
 const noReply=gas.doGet({parameter:{}}).text;ok(!noReply.includes('Học sinh')&&!noReply.includes('8A1'),'Không có API đọc dữ liệu lớp');
 for(let i=10;i<60;i++){const x=prepare(payload(i));x.student.code='MAU-'+i;ok(post(x).ok,'Nhiều học sinh '+i);}
 ok(sheets.get('TongHopHocSinh').rows.length===52,'50 HS khác và 1 HS ban đầu');
 const zero=prepare(payload(60));zero.detail.correct=zero.detail.wrong=zero.summary.correct=zero.summary.wrong=0;zero.summary.topics=Array.from({length:14},()=>[0,0]);post(zero);ok(sheets.get('ChiTietLuotChoi').rows.at(-1)[9]==='','Không trả lời → tỉ lệ trống, không giả 0%');
 const only=prepare(payload(61));only.kind='summary';only.detail=null;let before=sheets.get('ChiTietLuotChoi').rows.length;post(only);ok(sheets.get('ChiTietLuotChoi').rows.length===before,'Tổng hợp không tạo lượt chơi giả');
 const ackText=gas.doGet({parameter:{action:'receipt',eventId:p.eventId,key:p.receiptKey,nonce:'f'.repeat(32)}}).text;ok(!ackText.includes('name')&&!ackText.includes('className')&&!ackText.includes('xp'),'Biên nhận không có PII/điểm');
}
function client(storage=new Map(),settings={}){
 let now=100,posts=0,networkFailure=false,ackDisabled=false,serverWrite=true,removed=0;const listeners={},timeFns=[];
 const c={console,Map,Uint8Array,Event:class{constructor(type){this.type=type;}},AbortController,Date,TextEncoder,URL,performance:{now:()=>now},navigator:{onLine:true},crypto:crypto.webcrypto,
 localStorage:{get length(){return storage.size;},key:i=>[...storage.keys()][i],getItem:k=>storage.get(k)||null,setItem:(k,v)=>{if(settings.failStorage)throw Error('quota');storage.set(k,v);},removeItem:k=>storage.delete(k)},
 setTimeout:(f,ms)=>{const n=timeFns.length;timeFns.push(f);if(ms<=3000&&f.name==='')queueMicrotask(f);return n+1;},clearTimeout(){},
 addEventListener:(k,f)=>listeners[k]=f,dispatchEvent(){},
 document:{createElement:()=>({remove(){removed++;}}),head:{appendChild:script=>queueMicrotask(()=>{if(networkFailure)return script.onerror();const u=new URL(script.src),q=Object.fromEntries(u.searchParams);let r=gas.doGet({parameter:q});if(ackDisabled){r={text:'window.TGSheetsReceipt('+JSON.stringify({eventId:q.eventId,receiptKey:q.key,nonce:q.nonce,ok:false,state:'pending'})+');'};}vm.runInContext(r.text,c);})}},
 fetch:async(url,opts)=>{posts++;if(serverWrite)post(JSON.parse(opts.body));if(networkFailure)throw Error('offline');return {type:'opaque'};}};
 c.window=c;vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(root,'du-lieu/cot-truyen.js'),'utf8'),c);c.CAU_HINH={urlKetQua:'https://script.google.com/macros/s/TEST_ONLY/exec'};vm.runInContext(fs.readFileSync(path.join(root,'js/gui-ket-qua.js'),'utf8'),c);
 return {c,storage,listeners,advance:ms=>now+=ms,get posts(){return posts;},set networkFailure(v){networkFailure=v;},set ackDisabled(v){ackDisabled=v;},set serverWrite(v){serverWrite=v;}};
}
function state(){return {id:'clientprofile',maHS:'TEST-001',ten:'Hồ sơ mẫu',lop:'8A1',xp:10,dem:{dung:1,sai:1},tienDo:{1:[],2:[],3:[],4:[],5:[]},tk:{'tu-giac':[1,1]}};}
async function clientTests(){
 const t=client(),g=t.c.GuiKetQua,s=state();ok(g.validIdentity(s.ten,s.lop,s.maHS)&&!g.validIdentity(s.ten,'',s.maHS),'Bắt buộc định danh');
 const b={v:1,i:0,muc:1,kieu:'thu-thach',ds:[1,2,3,4],xpThu:10};g.start(b);g.shown(b);g.answer(b,true);g.hint(b);g.shown(b);g.answer(b,false);g.shown(b);g.skip(b);t.advance(5000);g.finish(s,b,'chua-dat');ok(!g.finish(s,b,'chua-dat'),'Chốt lượt đúng một lần');
 let p=JSON.parse([...t.storage.values()].find(x=>x.includes('receiptKey')));ok(p.detail.correct===1&&p.detail.wrong===1&&p.detail.hints===1&&p.detail.elapsedMs===5000&&p.detail.skipped===1,'Ghi nhận đúng các bộ đếm');
 t.ackDisabled=true;await g.flush();ok(g.status(s.maHS).text!=='Đã lưu kết quả'&&g.status(s.maHS).pending===1,'Opaque POST không được coi là đã lưu');
 const priorPosts=t.posts;t.ackDisabled=false;await g.flush();ok(g.status(s.maHS).text==='Đã lưu kết quả'&&t.posts===priorPosts,'Mất ACK: kiểm tra lại biên nhận, không POST trùng');
 const m=client();m.c.navigator.onLine=false;m.c.GuiKetQua.enqueue(state(),null);await m.c.GuiKetQua.flush();ok(m.posts===0&&m.c.GuiKetQua.status('TEST-001').pending===1,'Offline giữ hàng đợi');
 const restored=client(m.storage);await restored.c.GuiKetQua.flush();ok(restored.c.GuiKetQua.status('TEST-001').text==='Đã lưu kết quả','Mở lại phục hồi hàng đợi và gửi');
 ok(typeof restored.listeners.online==='function','Có hook online');
 const failed=client();failed.networkFailure=true;failed.c.GuiKetQua.enqueue(state(),null);await failed.c.GuiKetQua.flush();ok(failed.c.GuiKetQua.status('TEST-001').pending===1,'Lỗi mạng không xóa kết quả');failed.networkFailure=false;await failed.c.GuiKetQua.flush();ok(failed.c.GuiKetQua.status('TEST-001').pending===0,'Gửi lại thành công');
 const full=client(new Map(),{failStorage:true});full.c.GuiKetQua.enqueue(state(),null);ok(full.c.GuiKetQua.status('TEST-001').storageError,'Báo rõ khi bộ nhớ bị chặn');
 const disabled=client();disabled.c.CAU_HINH.urlKetQua='';disabled.c.GuiKetQua.enqueue(state(),null);await disabled.c.GuiKetQua.flush();ok(disabled.posts===0&&disabled.c.GuiKetQua.status('TEST-001').pending===1,'URL rỗng không gửi');
 // Hai tab cùng gửi đúng một sự kiện: server giữ 1 dòng.
 const a=client(),payloadId=a.c.GuiKetQua.enqueue(state(),null),bb=client(a.storage);await Promise.all([a.c.GuiKetQua.flush(),bb.c.GuiKetQua.flush()]);ok(sheets.get('_BienNhan').rows.filter(r=>r[0]===payloadId).length===1,'Hai máy khách retry cùng sự kiện không trùng');
}
(async()=>{await serverTests();await clientTests();console.log(JSON.stringify({passed:true,assertions:passed,environment:'Node VM + fake Google Sheets/transport; no live deployment',liveConcurrencyLoadTest:false},null,2));})().catch(e=>{console.error(e);process.exitCode=1;});
