// Gọi các hàm vòng chơi thật trong VM; DOM/âm thanh/timer giả lập, không phải kiểm thử giao diện.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');const root=path.resolve(__dirname,'..');let n=0;const ok=(x,m)=>{assert(x,m);n++;};
function node(){return {style:{},classList:{add(){},remove(){},toggle(){}},hidden:false,isConnected:true,value:'',dataset:{},innerHTML:'',textContent:'',appendChild(){},setAttribute(){},remove(){},focus(){},scrollIntoView(){},querySelector(){return node();},querySelectorAll(){return [];},getBoundingClientRect:()=>({left:0,top:0,width:100,height:50}),get nextElementSibling(){return node();}};}
const mem=new Map(),nodes=new Map(),c={console,Map,Uint8Array,Date,Event:class{},AbortController,performance:{now:()=>1000},crypto:crypto.webcrypto,navigator:{onLine:false},localStorage:{get length(){return mem.size;},key:i=>[...mem.keys()][i],getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v),removeItem:k=>mem.delete(k)},setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},requestAnimationFrame(){},addEventListener(){},dispatchEvent(){},scrollTo(){},matchMedia:()=>({matches:true}),document:{querySelector:s=>{if(!nodes.has(s))nodes.set(s,node());return nodes.get(s);},querySelectorAll:()=>[],createElement:node,addEventListener(){},body:node()},TextEncoder,TextDecoder,btoa,atob};c.window=c;vm.createContext(c);
for(const f of ['du-lieu/cot-truyen.js','du-lieu/cau-hoi.js','du-lieu/sinh-cau-hoi.js','du-lieu/cau-hinh.js','js/phan-so.js','js/ma-ket-qua.js','js/gui-ket-qua.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),c);
c.HienThi={esc:String,text:String,value:String};c.AmThanh={phat(){},moKhoa(){}};
c.ThuThach={shuffle:a=>a.slice(),ve:(box,q,opts)=>({opts,coTheNam:()=>false,coTheLoaiBo:()=>false})};
let src=fs.readFileSync(path.join(root,'js/game.js'),'utf8');src=src.replace('S = null; manMoDau();',`window.QA={moi,batDau,batDauOn,hienCau,tiepTheo,xuLy,manHoiSinh,thangTran,cauDauTri,thuaDauTri,ketQuaOn,manKetThuc,dungVatPham,get S(){return S;},get B(){return B;},setS(s){S=s;}};`);vm.runInContext(src,c);
const server={};vm.createContext(server);vm.runInContext(fs.readFileSync(path.join(root,'cong-cu/google-apps-script.gs'),'utf8'),server);
const api=c.QA;function reset(){mem.clear();const s=api.moi('Hồ sơ KIỂM THỬ','8A1','phap-su','🧙');s.maHS='TEST-001';api.setS(s);return s;}
function queued(){return [...mem].filter(([k])=>k.startsWith('tugq-outbox-v2:')).map(([,s])=>JSON.parse(s));}
for(let m=1;m<=3;m++)for(let v=1;v<=5;v++)for(const i of [0,1,3,4,5]){
 reset();api.batDau(v,i,m,false);if(api.B.kieu==='boss')api.hienCau();let loop=0;
 while(api.B&&loop++<30){if(!api.B.cur)api.hienCau();api.B.ctrl.opts.onXong({dung:true,dapAnHTML:'QA'});api.tiepTheo();}
 ok(loop<30,'Kết thúc lượt');const q=queued();ok(q.length===1,'Một sự kiện mỗi lượt');server.validate_(q[0]);ok(q[0].detail.correct===api.S.dem.dung&&q[0].detail.wrong===0,'Đếm đúng');ok(q[0].detail.xpEarned===api.S.xp&&q[0].summary.xp===api.S.xp,'XP gồm thưởng hoàn thành');ok(q[0].detail.status==='hoan-thanh','Trạng thái hoàn thành');
 if(v===5&&i===5){api.manKetThuc();const qs=queued();ok(qs.length===2&&qs.some(x=>x.kind==='summary'&&x.summary.finished),'Gửi tổng hợp cuối');qs.forEach(x=>server.validate_(x));}
}
reset();api.batDau(1,0,1,false);api.dungVatPham('goiY',node());api.dungVatPham('goiY',node());ok(api.B.doLuong.hints===1,'Gợi ý không đếm lặp');
for(let i=0;i<4;i++){api.B.ctrl.opts.onXong({dung:false,dapAnHTML:'QA'});api.tiepTheo();}
let q=queued()[0];ok(q.detail.wrong===4&&q.detail.hints===1&&q.detail.status==='chua-dat','Gửi khi không đạt');server.validate_(q);
reset();api.batDau(1,2,1,false);for(let i=0;i<4;i++){api.cauDauTri();api.B.ctrl.opts.onXong({dung:true,dapAnHTML:'QA'});}api.cauDauTri();api.B.ctrl.opts.onXong({dung:false,dapAnHTML:'QA'});api.thangTran();q=queued()[0];ok(q.detail.correct===4&&q.detail.wrong===1&&q.detail.total===5&&q.detail.totalBasis==='shown','Đấu trí đếm câu thật');server.validate_(q);
reset();api.S.on=[c.CAU_HOI[0],c.CAU_HOI[1]];api.batDauOn();for(let i=0;i<2;i++){api.B.ctrl.opts.onXong({dung:true,dapAnHTML:'QA'});api.tiepTheo();}q=queued()[0];ok(q.detail.status==='on-xong'&&q.detail.correct===2,'Ôn tập');server.validate_(q);
console.log(JSON.stringify({passed:true,assertions:n,normalBossRuns:75,environment:'Production game functions; DOM/timers/audio mocked; server validation on generated records'},null,2));
